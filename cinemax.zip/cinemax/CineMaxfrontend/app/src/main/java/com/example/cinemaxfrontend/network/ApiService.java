package com.example.cinemaxfrontend.network;

import com.example.cinemaxfrontend.model.Movie;
import com.example.cinemaxfrontend.model.User;
import com.example.cinemaxfrontend.model.Reservation;
import com.example.cinemaxfrontend.model.ContactMessage;
import java.util.List;
import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.POST;
import retrofit2.http.Path;
import retrofit2.http.Body;

public interface ApiService {

    // Movies
    @GET("api/movies")
    Call<List<Movie>> getAllMovies();

    @GET("api/movies/{id}")
    Call<Movie> getMovieById(@Path("id") Long id);

    // Users
    @POST("api/users/login")
    Call<User> login(@Body User user);

    @POST("api/users")
    Call<User> register(@Body User user);

    // Reservations
    @POST("api/reservations")
    Call<Reservation> createReservation(@Body Reservation reservation);

    @GET("api/reservations/user/{userId}")
    Call<List<Reservation>> getUserReservations(@Path("userId") Long userId);

    // Contact
    @POST("api/contact")
    Call<ContactMessage> sendContactMessage(@Body ContactMessage message);
}
