package com.example.cinemaxfrontend;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        if (getSupportActionBar() != null) {
            getSupportActionBar().hide();
        }

        findViewById(R.id.btnGlobalMenu).setOnClickListener(v -> showMenuDialog());

        // Charger le HomeFragment par défaut au démarrage
        if (savedInstanceState == null) {
            loadFragment(new HomeFragment());
        }
    }

    private com.google.android.material.bottomsheet.BottomSheetDialog menuDialog;

    private void showMenuDialog() {
        if (menuDialog == null) {
            android.view.View view = getLayoutInflater().inflate(R.layout.menu_layout, null);
            menuDialog = new com.google.android.material.bottomsheet.BottomSheetDialog(this);

            view.findViewById(R.id.btnMenuHome).setOnClickListener(v -> {
                loadFragment(new HomeFragment());
                menuDialog.dismiss();
            });

            view.findViewById(R.id.btnMenuLogin).setOnClickListener(v -> {
                loadFragment(new LoginFragment());
                menuDialog.dismiss();
            });

            view.findViewById(R.id.btnMenuReservations).setOnClickListener(v -> {
                android.content.SharedPreferences prefs = getSharedPreferences("UserSession",
                        android.content.Context.MODE_PRIVATE);
                if (prefs.contains("USER_ID")) {
                    loadFragment(new ReservationFragment());
                } else {
                    android.widget.Toast.makeText(this, "Please Login First", android.widget.Toast.LENGTH_SHORT).show();
                    loadFragment(new LoginFragment());
                }
                menuDialog.dismiss();
            });

            view.findViewById(R.id.btnMenuContact).setOnClickListener(v -> {
                loadFragment(new ContactFragment());
                menuDialog.dismiss();
            });

            menuDialog.setContentView(view);
        }
        menuDialog.show();
    }

    public void loadFragment(Fragment fragment) {
        FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
        transaction.replace(R.id.fragment_container, fragment);
        transaction.addToBackStack(null);
        transaction.commit();
    }

    // Surcharge de l'appui sur retour pour dépiler si nécessaire, généralement géré
    // par
    // AppCompatActivity automatiquement si la pile de retour est utilisée.
}
