package com.example.cinemaxfrontend;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.cinemaxfrontend.adapter.ReservationAdapter;
import com.example.cinemaxfrontend.model.Reservation;
import com.example.cinemaxfrontend.network.ApiClient;
import com.example.cinemaxfrontend.network.ApiService;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class ReservationFragment extends Fragment {

    private RecyclerView rvReservations;
    private ReservationAdapter adapter;
    private ApiService apiService;

    private TextView tvEmptyState;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
            @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_reservation, container, false);

        rvReservations = view.findViewById(R.id.rvReservations);
        tvEmptyState = view.findViewById(R.id.tvEmptyState);

        rvReservations.setLayoutManager(new LinearLayoutManager(getContext()));

        adapter = new ReservationAdapter(new ArrayList<>());
        rvReservations.setAdapter(adapter);

        apiService = ApiClient.getApiService();

        loadReservations();

        return view;
    }

    private void loadReservations() {
        if (getContext() == null)
            return;

        SharedPreferences prefs = getContext().getSharedPreferences("UserSession", Context.MODE_PRIVATE);
        if (!prefs.contains("USER_ID")) {
            Toast.makeText(getContext(), "Please login to see reservations", Toast.LENGTH_SHORT).show();
            rvReservations.setVisibility(View.GONE);
            tvEmptyState.setText("Please login to view reservations.");
            tvEmptyState.setVisibility(View.VISIBLE);
            return;
        }

        Long userId = prefs.getLong("USER_ID", -1);
        Log.d("ReservationFragment", "Fetching reservations for UserID: " + userId);

        apiService.getUserReservations(userId).enqueue(new Callback<List<Reservation>>() {
            @Override
            public void onResponse(Call<List<Reservation>> call, Response<List<Reservation>> response) {
                if (response.isSuccessful() && response.body() != null) {
                    List<Reservation> reservations = response.body();
                    Log.d("ReservationFragment", "Reservations found: " + reservations.size());

                    if (reservations.isEmpty()) {
                        rvReservations.setVisibility(View.GONE);
                        tvEmptyState.setText("No reservations found.");
                        tvEmptyState.setVisibility(View.VISIBLE);
                    } else {
                        rvReservations.setVisibility(View.VISIBLE);
                        tvEmptyState.setVisibility(View.GONE);
                        adapter.updateReservations(reservations);
                    }
                } else {
                    Log.e("ReservationFragment", "Error response: " + response.code());
                    Toast.makeText(getContext(), "Failed to load: " + response.message(), Toast.LENGTH_LONG).show();
                    tvEmptyState.setText("Error loading data.");
                    tvEmptyState.setVisibility(View.VISIBLE);
                }
            }

            @Override
            public void onFailure(Call<List<Reservation>> call, Throwable t) {
                Log.e("ReservationFragment", "Network Failure", t);
                Toast.makeText(getContext(), "Network Error: " + t.getMessage(), Toast.LENGTH_LONG).show();
                tvEmptyState.setText("Network error. Please try again.");
                tvEmptyState.setVisibility(View.VISIBLE);
            }
        });
    }
}
