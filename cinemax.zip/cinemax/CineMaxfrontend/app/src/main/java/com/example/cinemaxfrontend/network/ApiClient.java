package com.example.cinemaxfrontend.network;

import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class ApiClient {
    // IMPORTANT: Pour l'émulateur Android, localhost est 10.0.2.2
    // Si vous utilisez un vrai téléphone, utilisez l'IP locale de votre PC (ex:
    // 192.168.1.XX)
    private static final String BASE_URL = "http://10.0.2.2:8080/";
    private static Retrofit retrofit = null;

    public static ApiService getApiService() {
        if (retrofit == null) {
            retrofit = new Retrofit.Builder()
                    .baseUrl(BASE_URL)
                    .addConverterFactory(GsonConverterFactory.create())
                    .build();
        }
        return retrofit.create(ApiService.class);
    }
}
