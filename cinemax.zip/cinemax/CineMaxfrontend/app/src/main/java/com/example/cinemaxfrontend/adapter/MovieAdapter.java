package com.example.cinemaxfrontend.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.cinemaxfrontend.R;
import com.example.cinemaxfrontend.model.Movie;

import java.util.List;

public class MovieAdapter extends RecyclerView.Adapter<MovieAdapter.MovieViewHolder> {

    private final Context context;
    private final List<Movie> movieList;
    private final OnItemClickListener listener; // Variable pour le listener

    /**
     * Interface pour gérer le clic sur un élément de la liste.
     */
    public interface OnItemClickListener {
        void onItemClick(Movie movie);
    }

    /**
     * Constructeur de l'adapter.
     *
     * @param context   Le contexte de l'application.
     * @param movieList La liste des films à afficher.
     * @param listener  Le listener pour les événements de clic.
     */
    public MovieAdapter(Context context, List<Movie> movieList, OnItemClickListener listener) {
        this.context = context;
        this.movieList = movieList;
        this.listener = listener;
    }

    @NonNull
    @Override
    public MovieViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_movie, parent, false);
        return new MovieViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull MovieViewHolder holder, int position) {
        // Récupérer le film à la position actuelle
        Movie movie = movieList.get(position);

        // Lier les données du film aux vues
        holder.tvTitle.setText(movie.getTitle());
        String genreAndDuration = (movie.getGenre() != null ? movie.getGenre() : "Inconnu") +
                (movie.getDuration() != null ? " • " + movie.getDuration() : "");
        holder.tvGenre.setText(genreAndDuration);

        if (movie.getPrice() != null) {
            holder.tvPrice.setText(String.format(java.util.Locale.US, "$%.2f", movie.getPrice()));
            holder.tvPrice.setVisibility(View.VISIBLE);
        } else {
            holder.tvPrice.setVisibility(View.GONE);
        }

        // Gestion de l'image avec Glide
        String imageUrl = movie.getImageUrl();
        if (imageUrl != null && !imageUrl.isEmpty()) {
            imageUrl = imageUrl.trim(); // Supprimer les espaces
            // Correctif pour accéder à localhost depuis l'émulateur
            if (imageUrl.contains("localhost")) {
                imageUrl = imageUrl.replace("localhost", "10.0.2.2");
            }
            // Optimiser les images TMDB
            if (imageUrl.contains("image.tmdb.org") && imageUrl.contains("/original/")) {
                imageUrl = imageUrl.replace("/original/", "/w500/");
            }

            android.util.Log.d("MovieAdapter", "Loading image: " + imageUrl);

            com.bumptech.glide.Glide.with(context)
                    .load(imageUrl)
                    .placeholder(android.R.drawable.ic_menu_gallery)
                    .error(android.R.drawable.ic_menu_report_image)
                    .fitCenter()
                    .diskCacheStrategy(com.bumptech.glide.load.engine.DiskCacheStrategy.ALL)
                    .into(holder.ivPoster);
        } else {
            holder.ivPoster.setImageResource(android.R.drawable.ic_menu_gallery);
        }

        holder.itemView.setOnClickListener(v -> {
            if (listener != null) {
                listener.onItemClick(movie);
            }
        });
    }

    @Override
    public int getItemCount() {
        return movieList.size();
    }

    // --- DÉBUT DE L'AJOUT ---
    /**
     * Met à jour la liste des films dans l'adaptateur et notifie le RecyclerView du
     * changement.
     * 
     * @param newMovies La nouvelle liste de films à afficher.
     */
    @android.annotation.SuppressLint("NotifyDataSetChanged")
    public void updateMovies(List<Movie> newMovies) {
        // 1. Vider la liste actuelle
        this.movieList.clear();
        // 2. Ajouter tous les nouveaux films
        this.movieList.addAll(newMovies);
        // 3. Notifier l'adaptateur que les données ont changé pour rafraîchir
        // l'affichage
        notifyDataSetChanged();
    }
    // --- FIN DE L'AJOUT ---

    public static class MovieViewHolder extends RecyclerView.ViewHolder {
        ImageView ivPoster;
        TextView tvTitle, tvGenre, tvPrice;

        public MovieViewHolder(@NonNull View itemView) {
            super(itemView);
            ivPoster = itemView.findViewById(R.id.ivMoviePoster);
            tvTitle = itemView.findViewById(R.id.tvMovieTitle);
            tvGenre = itemView.findViewById(R.id.tvMovieGenre);
            tvPrice = itemView.findViewById(R.id.tvPrice);
        }
    }
}
