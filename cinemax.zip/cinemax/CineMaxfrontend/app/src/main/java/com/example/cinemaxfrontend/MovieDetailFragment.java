package com.example.cinemaxfrontend;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import androidx.fragment.app.Fragment;

import com.example.cinemaxfrontend.model.Movie;
import com.example.cinemaxfrontend.model.Reservation;
import com.example.cinemaxfrontend.network.ApiClient;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MovieDetailFragment extends Fragment {

    private static final String ARG_MOVIE = "movie_data";
    private Movie movie;

    public static MovieDetailFragment newInstance(Movie movie) {
        MovieDetailFragment fragment = new MovieDetailFragment();
        Bundle args = new Bundle();
        args.putSerializable(ARG_MOVIE, movie);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            movie = (Movie) getArguments().getSerializable(ARG_MOVIE);
        }
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
            @Nullable Bundle savedInstanceState) {
        // Need a new layout for fragment or reuse activity layout (might need tweaks
        // for coordinator layout behavior in fragment)
        View view = inflater.inflate(R.layout.fragment_movie_detail, container, false);

        if (movie != null) {
            setupViews(view, movie);
        } else {
            Toast.makeText(getContext(), "Error: Movie not found", Toast.LENGTH_SHORT).show();
            // Go back
            ((MainActivity) requireActivity()).loadFragment(new HomeFragment());
        }

        // Back button logic if needed, or rely on hardware back button handled by
        // MainActivity

        return view;
    }

    private void setupViews(View view, Movie movie) {
        TextView tvTitle = view.findViewById(R.id.tvDetailTitle);
        tvTitle.setText(movie.getTitle());

        TextView tvGenre = view.findViewById(R.id.tvDetailGenre);
        tvGenre.setText(movie.getGenre() != null ? movie.getGenre() : "Unknown");

        TextView tvDuration = view.findViewById(R.id.tvDetailDuration);
        tvDuration.setText(movie.getDuration() != null ? "• " + movie.getDuration() : "");

        TextView tvSynopsis = view.findViewById(R.id.tvDetailSynopsis);
        // If description exists in model
        // tvSynopsis.setText(movie.getDescription());

        view.findViewById(R.id.btnBookTicket).setOnClickListener(v -> handleReservation(movie));
    }

    private void handleReservation(Movie movie) {
        if (getContext() == null)
            return;

        SharedPreferences prefs = getContext().getSharedPreferences("UserSession", Context.MODE_PRIVATE);
        if (!prefs.contains("USER_ID")) {
            Toast.makeText(getContext(), "Please Login to Book Tickets", Toast.LENGTH_SHORT).show();
            ((MainActivity) requireActivity()).loadFragment(new LoginFragment());
            return;
        }

        Long userId = prefs.getLong("USER_ID", -1);
        String username = prefs.getString("USERNAME", "Unknown");

        Reservation reservation = new Reservation();
        reservation.setMovieId(movie.getId());
        reservation.setTitle(movie.getTitle());
        reservation.setUserId(userId);
        reservation.setCustomerName(username);
        reservation.setSeatsBooked(1);

        ApiClient.getApiService().createReservation(reservation)
                .enqueue(new Callback<Reservation>() {
                    @Override
                    public void onResponse(Call<Reservation> call, Response<Reservation> response) {
                        if (response.isSuccessful()) {
                            Toast.makeText(getContext(), "Reservation Successful!", Toast.LENGTH_SHORT).show();
                        } else {
                            Toast.makeText(getContext(), "Reservation Failed.", Toast.LENGTH_SHORT).show();
                        }
                    }

                    @Override
                    public void onFailure(Call<Reservation> call, Throwable t) {
                        Toast.makeText(getContext(), "Error: " + t.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                });
    }
}
