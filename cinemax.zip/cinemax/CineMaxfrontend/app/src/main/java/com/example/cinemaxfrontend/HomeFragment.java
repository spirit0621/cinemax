package com.example.cinemaxfrontend;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.cinemaxfrontend.adapter.MovieAdapter;
import com.example.cinemaxfrontend.model.Movie;
import com.example.cinemaxfrontend.network.ApiClient;
import com.example.cinemaxfrontend.network.ApiService;
import com.google.android.material.bottomsheet.BottomSheetDialog;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class HomeFragment extends Fragment implements MovieAdapter.OnItemClickListener {

    private RecyclerView rvNowShowing;
    private MovieAdapter nowShowingAdapter;
    private ApiService apiService;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
            @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_home, container, false);
        initializeViews(view);
        setupRecyclerViews();
        sendRequest();
        return view;
    }

    private void initializeViews(View view) {
        rvNowShowing = view.findViewById(R.id.rvNowShowing);
        // rvComingSoon removed

        apiService = ApiClient.getApiService();

        // btnWatchNow removed
        // btnWatchNow removed
        // btnMenu removed and moved to Activity level
    }

    private void setupRecyclerViews() {
        nowShowingAdapter = new MovieAdapter(getContext(), new ArrayList<>(), this);
        rvNowShowing.setLayoutManager(new LinearLayoutManager(getContext(), LinearLayoutManager.HORIZONTAL, false));
        rvNowShowing.setAdapter(nowShowingAdapter);
    }

    private void sendRequest() {
        Call<List<Movie>> call = apiService.getAllMovies();
        call.enqueue(new Callback<List<Movie>>() {
            @Override
            public void onResponse(Call<List<Movie>> call, Response<List<Movie>> response) {
                if (response.isSuccessful() && response.body() != null) {
                    List<Movie> allMovies = response.body();
                    // Display all movies in the single list
                    nowShowingAdapter.updateMovies(allMovies);

                } else {
                    Log.e("HomeFragment", "Response not successful. Code: " + response.code());
                    Toast.makeText(getContext(), "Failed to fetch movies", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<List<Movie>> call, Throwable t) {
                Log.e("HomeFragment", "API call failed", t);
                Toast.makeText(getContext(), "Error: " + t.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void showMenuDialog() {
        if (getContext() == null)
            return;
        BottomSheetDialog dialog = new BottomSheetDialog(getContext());
        View view = getLayoutInflater().inflate(R.layout.menu_layout, null);

        view.findViewById(R.id.btnMenuHome).setOnClickListener(v -> {
            ((MainActivity) requireActivity()).loadFragment(new HomeFragment());
            dialog.dismiss();
        });

        view.findViewById(R.id.btnMenuLogin).setOnClickListener(v -> {
            ((MainActivity) requireActivity()).loadFragment(new LoginFragment());
            dialog.dismiss();
        });

        view.findViewById(R.id.btnMenuReservations).setOnClickListener(v -> {
            SharedPreferences prefs = getContext().getSharedPreferences("UserSession", Context.MODE_PRIVATE);
            if (prefs.contains("USER_ID")) {
                ((MainActivity) requireActivity()).loadFragment(new ReservationFragment());
            } else {
                Toast.makeText(getContext(), "Please Login First", Toast.LENGTH_SHORT).show();
                ((MainActivity) requireActivity()).loadFragment(new LoginFragment());
            }
            dialog.dismiss();
        });

        view.findViewById(R.id.btnMenuContact).setOnClickListener(v -> {
            ((MainActivity) requireActivity()).loadFragment(new ContactFragment());
            dialog.dismiss();
        });

        dialog.setContentView(view);
        dialog.show();
    }

    @Override
    public void onItemClick(Movie movie) {
        // Handle movie detail navigation inside MainActivity if possible or replace
        // fragment
        // For simplicity, let's keep MovieDetail as an Activity for now (as mixing
        // fragment/activity navigation is okay-ish)
        // OR better, assuming user wants EVERYTHING as fragment:
        // ((MainActivity)
        // requireActivity()).loadFragment(MovieDetailFragment.newInstance(movie));

        // Let's implement MovieDetailActivity transition first to stay safe,
        // OR better, stick to the prompt "tout sous forme de fragment".
        // I will create a MovieDetailFragment.
        ((MainActivity) requireActivity()).loadFragment(MovieDetailFragment.newInstance(movie));
    }
}
