package com.example.cinemaxfrontend;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.example.cinemaxfrontend.model.ContactMessage;
import com.example.cinemaxfrontend.network.ApiClient;
import com.example.cinemaxfrontend.network.ApiService;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class ContactFragment extends Fragment {

    private EditText etName, etEmail, etSubject, etMessage;
    private Button btnSend;
    private ApiService apiService;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
            @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_contact, container, false);

        etName = view.findViewById(R.id.etName);
        etEmail = view.findViewById(R.id.etEmail);
        etSubject = view.findViewById(R.id.etSubject);
        etMessage = view.findViewById(R.id.etMessage);
        btnSend = view.findViewById(R.id.btnSend);

        apiService = ApiClient.getApiService();

        btnSend.setOnClickListener(v -> sendMessage());

        return view;
    }

    private void sendMessage() {
        String name = etName.getText().toString();
        String email = etEmail.getText().toString();
        String subject = etSubject.getText().toString();
        String messageText = etMessage.getText().toString();

        if (name.isEmpty() || email.isEmpty() || messageText.isEmpty()) {
            Toast.makeText(getContext(), "Please fill required fields", Toast.LENGTH_SHORT).show();
            return;
        }

        ContactMessage msg = new ContactMessage();
        msg.setName(name);
        msg.setEmail(email);
        msg.setSubject(subject);
        msg.setMessage(messageText);

        apiService.sendContactMessage(msg).enqueue(new Callback<ContactMessage>() {
            @Override
            public void onResponse(Call<ContactMessage> call, Response<ContactMessage> response) {
                if (response.isSuccessful()) {
                    Toast.makeText(getContext(), "Message sent successfully!", Toast.LENGTH_SHORT).show();
                    ((MainActivity) requireActivity()).loadFragment(new HomeFragment());
                } else {
                    Toast.makeText(getContext(), "Failed to send message.", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<ContactMessage> call, Throwable t) {
                Toast.makeText(getContext(), "Error: " + t.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }
}
