package com.example.cinemaxfrontend;

import android.os.Bundle;
import android.widget.TextView;import androidx.appcompat.app.AppCompatActivity;

import com.example.cinemaxfrontend.model.Movie;

public class ActivityMovieDetail extends AppCompatActivity {

    private Movie movie;
    private TextView tvDetailTitle;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // Liez cette activité à son fichier de layout
        setContentView(R.layout.activity_movie_detail);

        // Initialiser les vues
        tvDetailTitle = findViewById(R.id.tvDetailTitle);

        // Récupérer l'objet Movie envoyé par MainActivity
        if (getIntent() != null && getIntent().hasExtra("MOVIE_OBJECT")) {
            movie = (Movie) getIntent().getSerializableExtra("MOVIE_OBJECT");
        }

        // Utiliser l'objet 'movie' pour afficher les détails
        if (movie != null) {
            // Afficher le titre du film dans le TextView
            tvDetailTitle.setText(movie.getTitle());

            // Vous pouvez aussi définir le titre de la barre d'action
            if (getSupportActionBar() != null) {
                getSupportActionBar().setTitle(movie.getTitle());
                // Ajoute une flèche de retour vers MainActivity
                getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            }
        }
    }

    // Gère le clic sur la flèche de retour dans la barre d'action
    @Override
    public boolean onSupportNavigateUp() {
        onBackPressed();
        return true;
    }
}
