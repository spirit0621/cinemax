# Cahier Technique - Projet Cinemax2

## 1. Stack Technologique

### Backend
- **Langage** : Java (JDK 17+)
- **Framework** : Spring Boot 3.x
  - **Spring Web** : Pour l'architecture MVC et les API REST.
  - **Spring Data JPA** : Abstraction pour l'accès aux données.
  - **Hibernate** : Implémentation JPA (ORM).
- **Base de Données** : MySQL 8.0.

### Frontend
- **Moteur de Template** : Freemarker (fichiers `.ftlh`) / Thymeleaf (si utilisé).
- **Langages** : HTML5, CSS3, JavaScript (Vanilla).
- **Style** : CSS personnalisé responsive.

### Outils de Développement
- **Gestionnaire de dépendances** : Maven.
- **IDE** : VS Code / IntelliJ.
- **Versionning** : Git.

## 2. Architecture

L'application suit une architecture en couches (Layered Architecture) classique de Spring Boot :

1.  **Controller Layer (`cinemax.controller`)** : Gère les requêtes HTTP, appelle les services et retourne les vues ou les données JSON.
2.  **Service Layer (`cinemax.service`)** : Contient la logique métier (Business Logic).
3.  **Repository Layer (`cinemax.repository`)** : Interface avec la base de données via Spring Data JPA.
4.  **Model Layer (`cinemax.model`)** : Entités JPA représentant les tables de la base de données.

## 3. Modèle de Données (Schéma BDD)

Les principales entités sont :

- **User**
  - `id` (PK)
  - `username`
  - `password` (Encrypted)
  - `email`
  - `role`

- **Movie**
  - `id` (PK)
  - `title`
  - `description`
  - `duration`
  - `imageUrl`

- **Reservation**
  - `id` (PK)
  - `user_id` (FK)
  - `movie_id` (FK)
  - `reservationDate`
  - `seats`

- **Comment**
  - `id` (PK)
  - `content`
  - `user_id` (FK)
  - `movie_id` (FK)
  - `rating` (si applicable)

## 4. Configuration
Le fichier `application.properties` configure la connexion MySQL sur le port 3306 et le serveur Tomcat sur le port 8080.
Mode `ddl-auto=update` pour la mise à jour automatique du schéma.

## 5. Sécurité
L'application doit gérer l'authentification des utilisateurs pour protéger les routes de réservation et de commentaire.
