# Plan de Migration : Frontend Web vers Application Android Native (Java/XML)

**Projet :** CinéMax
**Cible :** Application Android Native (Java)
**Type de Projet :** Empty Views Activity
**Build Configuration :** Kotlin DSL
**Localisation du projet :** `CineMaxfrontend2/`
**Auteur :** Antigravity

---

## 1. Objectif
Transformer l'interface web actuelle (HTML/CSS/JS Vanilla) en une application mobile Android native classique en **Java**, utilisant les **Vues XML** pour l'interface, tout en conservant la communication avec l'API Backend Spring Boot existante.

## 2. Stack Technique Recommandée

*   **Langage :** **Java** (Demande explicite).
*   **Interface Utilisateur (UI) :** **Layouts XML** (ConstraintLayout, LinearLayout, FrameLayout).
*   **Architecture :** MVVM (recommandé) ou MVC classique (plus simple pour débuter en Java).
*   **Réseau (API) :** **Retrofit** avec Gson (Standard robuste pour Java).
*   **Asynchronisme :** `Call<T>` (Callback Hell) ou **RxJava** (plus complexe) ou `ExecutorService` (Threads).
*   **Navigation :** Intents (Navigation classique entre Activités) ou Fragments.
*   **Chargement d'images :** **Glide** ou Picasso (Standards pour les Views).
*   **Listes :** RecyclerView + Adapters.

---

## 3. Analyse de l'existant (Web) vs Cible (Android Java)

| Fonctionnalité Web (JS) | Équivalent Android (Java/XML) |
| :--- | :--- |
| `fetch()` / `apiRequest()` | Interface **Retrofit** + Callbacks (`enqueue`) |
| HTML `<div>` | Fichiers `layout/*.xml` (`<LinearLayout>`, `<ConstraintLayout>`) |
| Navigation `showPage()` | `Intent` (nouvelle Activity) ou `FragmentTransaction` |
| Variable Globale `currentUser` | Singleton `SessionManager.java` ou `SharedPreferences` |
| CSS Gradients | Drawable XML (`shape` avec `<gradient>`) |
| CSS `card-hover` | `CardView` avec elevation et attributs ripple |
| Formulaires HTML | `EditText` mappés avec `findViewById()` |

---

## 4. Plan de Mise en Œuvre (Étape par Étape)

### Phase 1 : Initialisation et Configuration
1.  **Création du projet** :
    *   Template : **Empty Views Activity**.
    *   Language : **Java**.
    *   Build Configuration Language : **Kotlin DSL** (`build.gradle.kts`).
2.  **Dépendances (`build.gradle.kts`)** :
    *   Ajouter `Retrofit` et `Gson Converter`.
    *   Ajouter `Glide` (pour les images).
    *   Ajouter `Material Components` (si pas déjà présent).
3.  **Manifest** :
    *   Ajouter `<uses-permission android:name="android.permission.INTERNET" />`.
    *   Autoriser le trafic http clair (non-https) : `android:usesCleartextTraffic="true"` (car API locale).

### Phase 2 : Couche de Données (Data Layer)
*   **Modèles (POJO - Plain Old Java Objects)** : Créer les classes Java avec Getters/Setters correspondant au JSON.
    *   `Movie.java`
    *   `User.java`
    *   `Reservation.java`
*   **Interface API** : Interface Java Retrofit.
    ```java
    @GET("/movies")
    Call<List<Movie>> getMovies();
    ```
*   **Client API** : Classe Singleton `ApiClient.java` pour instancier Retrofit.

### Phase 3 : Interface Utilisateur (Layouts XML)
Créer les fichiers XML dans `res/layout/` :
1.  `activity_login.xml` : `EditText` (user, pass), `Button` (Login).
2.  `activity_main.xml` (Accueil) : `RecyclerView` pour la grille de films.
3.  `item_movie.xml` : Le design d'une seule carte de film (ImageView + TextViews titre/prix).
4.  `activity_movie_detail.xml` : Grande image, description, bouton "Réserver".
5.  `dialog_booking.xml` : Layout pour la modale de réservation.

### Phase 4 : Logique Métier (Activités Java)
Connecter les XML au code Java :
1.  **LoginActivity.java** :
    *   `findViewById` pour récupérer les champs.
    *   Appel Retrofit `/users/login` au clic du bouton.
    *   Si succès -> `startActivity(new Intent(this, MainActivity.class))`.
2.  **MainActivity.java** :
    *   Configurer le `RecyclerView` et son `MovieAdapter`.
    *   Appel Retrofit `/movies` et mise à jour de l'adapteur.
3.  **MovieDetailActivity.java** :
    *   Récupérer l'ID du film passé via l'Intent.
    *   Afficher les détails.
    *   Afficher une `AlertDialog` avec le layout `dialog_booking.xml` pour réserver.

### Phase 5 : Fonctionnalités Avancées
*   **Session** : Utiliser `SharedPreferences` pour stocker l'objet User connecté et son token si besoin.
*   **Menu** : Ajouter une `BottomNavigationView` ou un `OptionMenu` pour naviguer vers "Mes Réservations" ou "Profil".
*   **Admin** : Si l'utilisateur est admin, afficher un bouton flottant (FAB) pour ajouter un film (ouvre `AddMovieActivity`).

---

## 5. Structure du Projet (Dossier CineMaxfrontend2)

```text
app/src/main/java/com/cinemax/app/
├── model/             # Movie.java, User.java... (POJO)
├── network/
│   ├── ApiClient.java
│   └── ApiService.java (Interface)
├── adapter/
│   └── MovieAdapter.java (ViewHolder pour RecyclerView)
├── activity/
│   ├── LoginActivity.java
│   ├── MainActivity.java
│   ├── MovieDetailActivity.java
│   └── AdminActivity.java
└── utils/
    └── SessionManager.java
```

## 6. Estimation (Java/XML)
*   Le code est plus verbeux qu'en Kotlin/Compose (plus de "boilerplate").
*   Gestion des `findViewById` et des `Callbacks` Retrofit.
*   **Total estimé :** ~20 à 25 heures.
