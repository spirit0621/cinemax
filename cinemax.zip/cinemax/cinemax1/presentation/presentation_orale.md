# Présentation Orale - Projet Cinemax2

> Ce document structure la présentation orale. Chaque section correspond à une diapositive (Slide).

---

## Slide 1 : Titre et Introduction
**Titre** : Cinemax2 - Votre nouveau portail cinéma
**Sous-titre** : Présentation du projet de fin de module
**Présenté par** : [Votre Nom]

### 🗣️ Notes pour l'oral :
- Bonjour à tous.
- Je vous présente aujourd'hui "Cinemax2", une application web complète dédiée à la gestion et à la réservation de films.
- Ce projet a été réalisé dans le but de mettre en pratique les compétences acquises en développement Java Spring Boot et en conception web.

---

## Slide 2 : Le Besoin (Problématique)
**Points clés** :
- Besoin de digitaliser l'expérience client.
- Faciliter la réservation de places.
- Créer un espace d'échange (avis).

### 🗣️ Notes pour l'oral :
- Pourquoi ce projet ?
- Aujourd'hui, les spectateurs veulent de l'immédiateté : voir les films à l'affiche et réserver sans faire la queue.
- De plus, l'aspect social est crucial : on veut savoir ce que les autres ont pensé du film avant d'y aller.
- Cinemax2 répond à ces deux besoins : réservation simplifiée et avis communautaires.

---

## Slide 3 : Les Fonctionnalités (Démonstration)
**Points clés** :
1. **Catalogue** : Liste visuelle des films.
2. **Authentification** : Sécurisation des comptes.
3. **Réservation** : Parcours utilisateur simple.
4. **Social** : Commentaires en temps réel.

### 🗣️ Notes pour l'oral :
- L'application s'articule autour de 3 axes majeurs.
- D'abord, la découverte : un catalogue clair et visuel.
- Ensuite, l'action : la possibilité de se créer un compte et de réserver en quelques clics.
- Enfin, l'échange : post-film, l'utilisateur peut laisser une critique.
- (Si démo possible : "Je vais vous montrer rapidement comment on réserve un billet...")

---

## Slide 4 : Architecture Technique
**Schéma** : Java Spring Boot <--> MySQL
**Points clés** :
- **Backend** : Java 17, Spring Boot (MVC).
- **Data** : MySQL avec Hibernate (JPA).
- **Frontend** : Freemarker, HTML5/CSS3.

### 🗣️ Notes pour l'oral :
- Côté technique, j'ai choisi une stack robuste et éprouvée.
- Spring Boot pour le backend permet une structuration claire en couches (Contrôleur, Service, Repository).
- J'utilise MySQL pour la persistance des données, garantissant la fiabilité des réservations.
- Le frontend est généré côté serveur (SSR) avec Freemarker pour un rendu rapide et SEO-friendly (si applicable).

---

## Slide 5 : Difficultés et Solutions
**Tableau** :
- *Problème* : Gestion des relations BDD (OneToMany).
- *Solution* : Utilisation des annotations JPA (@OneToMany, @ManyToOne).
- *Problème* : Design responsive.
- *Solution* : Utilisation de Flexbox et CSS Grid.

### 🗣️ Notes pour l'oral :
- Durant le développement, j'ai fait face à quelques défis.
- Notamment la modélisation des relations entre Utilisateurs et Réservations. J'ai dû bien configurer mes entités JPA pour éviter les boucles infinies ou les erreurs de mapping.
- Le design a aussi demandé du travail pour être agréable sur mobile comme sur desktop.

---

## Slide 6 : Conclusion et Perspectives
**Points clés** :
- **Bilan** : Application fonctionnelle et robuste.
- **Futur** : Ajout du paiement en ligne, système de notation par étoiles, application mobile.

### 🗣️ Notes pour l'oral :
- Pour conclure, Cinemax2 est une base solide pour une gestion de cinéma.
- L'objectif principal est atteint : on peut s'inscrire, voir des films et réserver.
- Pour la suite, j'envisage d'intégrer une passerelle de paiement (comme Stripe) et peut-être une API pour une future application mobile native.
- Merci de votre écoute, avez-vous des questions ?
