#  Cahier des Charges & Spécifications Techniques - CinéMax

## 1. Présentation Générale

### 1.1. Contexte du Projet
**CinéMax** est une plateforme web moderne de gestion de cinéma. Elle a pour vocation de digitaliser l'expérience client (réservation, consultation) tout en offrant des outils puissants d'administration pour les gérants de salles. Le projet met l'accent sur une interface utilisateur fluide ("User Experience") et une architecture technique robuste.

### 1.2. Objectifs Principaux
1.  **Expérience Utilisateur Premium** : Interface immersive, fluide et responsive.
2.  **Simulation Réaliste** : Gestion complète du cycle de réservation, y compris une simulation de paiement.
3.  **Administration Simplifiée** : Back-office intuitif pour la gestion quotidienne (films, séances).
4.  **Extensibilité** : Architecture modulaire permettant l'ajout futur de fonctionnalités (app mobile, API tierces).

---

## 2. 📋 Cahier des Charges Fonctionnel

### 2.1. Acteurs du Système (Personas)
| Acteur | Description | Objectifs |
| :--- | :--- | :--- |
| **Visiteur** | Utilisateur non connecté | Explorer les films, voir les bandes-annonces, consulter les horaires. |
| **Membre** | Utilisateur inscrit et connecté | Réserver des places, gérer son profil, commenter/noter les films, voir son historique. |
| **Administrateur** | Gestionnaire de la plateforme | Ajouter/Modifier des films, modérer les commentaires, analyser les ventes. |

### 2.2. Périmètre Fonctionnel

#### **Module 1 : Portail Public (Front-Office)**
*   **Landing Page Dynaamique** : Mise en avant des films "A l'affiche" et "Prochainement".
*   **Catalogue de Films** :
    *   Affichage sous forme de grille avec cartes interactives.
    *   Filtres par genre (Action, Comédie, Drame, etc.).
    *   Barre de recherche instantanée (par titre).
*   **Fiche Film Détaillée** :
    *   Informations complètes (Synopsis, Durée, Date de sortie, Prix).
    *   Intégration vidéo (Trailer YouTube).
    *   Liste des avis et note moyenne.
*   **Authentification et Sécurité** :
    *   Inscription avec validation de formulaire.
    *   Connexion sécurisée.
    *   Gestion de session persistante.

#### **Module 2 : Espace Membre**
*   **Système de Réservation** :
    *   Sélection de la séance.
    *   Choix du nombre de places.
    *   Récapitulatif de commande avec calcul dynamique du prix.
    *   Simulation de paiement (Interface carte bancaire).
    *   Génération de billet numérique (QR Code simulé / Récapitulatif).
*   **Social & Engagement** :
    *   Possibilité de laisser une note (1 à 5 étoiles).
    *   Rédaction de commentaires texte.
    *   Modification/Suppression de ses propres commentaires.
*   **Compte Utilisateur** :
    *   Historique des réservations.
    *   Mise à jour des informations personnelles.

#### **Module 3 : Administration (Back-Office)**
*   **Dashboard** : Vue synthétique (KPIs) : Nombre de films, ventes du jour, nouveaux inscrits.
*   **CRUD Films** : Création, Lecture, Mise à jour, Suppression de films.
    *   Gestion des images (Upload local).
*   **Modération** : Liste des commentaires signalés ou récents avec options de suppression.
*   **Gestion Utilisateurs** : Consultation de la base utilisateurs, bannissement.

### 2.3. Exigences Non-Fonctionnelles
*   **Performance** : Temps de chargement initial < 2 secondes.
*   **Responsive Design** : Compatible Desktop, Tablette et Mobile.
*   **Ergonomie** : Respect des standards UI/UX modernes (Feedback visuel, accessibilité).
*   **Sécurité** : Hachage des mots de passe (ex: BCrypt), Protection contre les injections SQL (via JPA), Validation des entrées.

---

## 3. 🛠️ Spécifications Techniques

### 3.1. Stack Technologique

#### **Backend**
*   **Langage** : Java 17 LTS.
*   **Framework** : Spring Boot 3.5.7.
    *   *Spring Web MVC* : Architecture REST/MVC.
    *   *Spring Data JPA* : Persistance des données (Hibernate).
    *   *Lombok* : Réduction du code boilerplate.
*   **Build Tool** : Maven.

#### **Frontend**
*   **Rendu** : Hybride.
    *   *Server-Side* : Freemarker (.ftlh) pour la structure initiale et le SEO.
    *   *Client-Side* : JavaScript Vanilla (ES6+) pour l'interactivité dynamique (SPA feeling).
*   **Styling** : **Tailwind CSS** (via CDN pour dev/prod simulée) + CSS Natif pour les animations spécifiques.
*   **Communication** : Fetch API pour les requêtes asynchrones vers le Backend.

#### **Données**
*   **Base de Données** : MySQL (Production/Dev) ou H2 (Test en mémoire).
*   **Stockage Fichiers** : Système de fichiers local (`user.home/cinemax-uploads`) servi via un endpoint statique Spring.

### 3.2. Architecture Logicielle

Le projet respecte le pattern **MVC (Modèle-Vue-Contrôleur)** strict :

1.  **Controller Layer** (`src/main/java/.../controller`) : Gère les requêtes HTTP, valide les entrées et appelle les services.
2.  **Service Layer** (`src/main/java/.../service`) : Contient la logique métier (Business Logic).
3.  **Repository Layer** (`src/main/java/.../repository`) : Interface avec la base de données (Spring Data JPA).
4.  **Entity Layer** (`src/main/java/.../entity`) : Représentation objets des tables SQL.
5.  **View Layer** (`src/main/resources/templates`) : Templates Freemarker.

### 3.3. Modèle de Données (Schéma Entité-Association)

#### **1. User (Utilisateur)**
*   `id` (PK) : Long
*   `email` : String (Unique)
*   `password` : String (Encrypted)
*   `firstName` : String
*   `lastName` : String
*   `role` : Enum (USER, ADMIN)

#### **2. Movie (Film)**
*   `id` (PK) : Long
*   `title` : String
*   `description` : Text
*   `genre` : String
*   `durationMin` : Integer
*   `releaseDate` : LocalDate
*   `price` : Double
*   `coverImageUrl` : String
*   `trailerUrl` : String

#### **3. Reservation**
*   `id` (PK) : Long
*   `user` : ManyToOne -> User
*   `movie` : ManyToOne -> Movie
*   `reservationDate` : LocalDateTime
*   `seatCount` : Integer
*   `totalPrice` : Double
*   `status` : Enum (CONFIRMED, CANCELLED)

#### **4. Review (Avis)**
*   `id` (PK) : Long
*   `user` : ManyToOne -> User
*   `movie` : ManyToOne -> Movie
*   `rating` : Integer (1-5)
*   `comment` : Text
*   `createdAt` : LocalDateTime

### 3.4. Interfaces API (Principaux Endpoints)

| Verbe | Chemin | Description | Accès |
| :--- | :--- | :--- | :--- |
| `GET` | `/` | Page d'accueil (Index) | Public |
| `GET` | `/api/movies` | Liste des films (JSON) | Public |
| `GET` | `/api/movies/{id}` | Détails d'un film | Public |
| `POST` | `/api/auth/register` | Inscription utilisateur | Public |
| `POST` | `/api/auth/login` | Connexion (Retourne Session/Token) | Public |
| `POST` | `/api/reservations` | Créer une réservation | **User** |
| `POST` | `/api/admin/movies` | Ajouter un film | **Admin** |
| `DELETE` | `/api/admin/movies/{id}` | Supprimer un film | **Admin** |

---

## 4. Déploiement et Environnement

*   **Pré-requis** : JDK 17, Maven 3+, Serveur MySQL.
*   **Configuration** : Fichier `application.properties` pour les accès BDD.
*   **Lancement** : `mvn spring-boot:run` ou exécution du JAR généré.

