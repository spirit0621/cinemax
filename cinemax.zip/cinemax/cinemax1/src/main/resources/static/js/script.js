// Configuration de l'API
const API_BASE_URL = 'http://localhost:8080/api';

// Variables globales
let currentUser = null;
let selectedRole = 'user';
let currentPage = 'home'; // Tracking global
let movies = [];
let reservations = [];
let comments = [];
let users = [];
let messages = [];
let currentBookingMovie = null;
let currentCommentMovie = null;
let currentEditMovie = null;
let pendingBooking = null;

// Fonctions utilitaires
function showToast(message, type = 'success') {
    const toast = document.createElement('div');
    toast.className = `toast px-6 py-3 rounded-lg text-white ${type === 'success' ? 'bg-green-500' : 'bg-red-500'}`;
    toast.textContent = message;
    document.getElementById('toast-container').appendChild(toast);
    setTimeout(() => toast.remove(), 3000);
}

function formatDateTime(dateString) {
    if (!dateString) return 'N/A';
    return new Date(dateString).toLocaleString('fr-FR', { dateStyle: 'medium', timeStyle: 'short' });
}

// Navigation
function showPage(pageName) {
    currentPage = pageName;
    document.querySelectorAll('.page').forEach(page => page.classList.remove('active'));
    document.querySelectorAll('.nav-link').forEach(link => link.classList.remove('active'));

    const targetPage = document.getElementById(pageName + '-page');
    if (targetPage) targetPage.classList.add('active');

    const navLink = document.getElementById('nav-' + pageName);
    if (navLink) navLink.classList.add('active');

    if (!currentUser && ['reservations', 'profile', 'admin'].includes(pageName)) {
        showPage('login');
        showToast('Veuillez vous connecter.', 'error');
        return;
    }
    if (pageName === 'admin') {
        if (currentUser?.userRole !== 'admin') {
            showPage('home');
            showToast('Accès administrateur requis.', 'error');
            return;
        }
        showAdminTab('dashboard'); // Default tab
    }
}

function showAdminTab(tabName) {
    document.querySelectorAll('.admin-section').forEach(sec => sec.classList.add('hidden'));
    document.getElementById('admin-' + tabName).classList.remove('hidden');

    document.querySelectorAll('.admin-tab').forEach(tab => {
        tab.classList.remove('active', 'bg-slate-700', 'text-white');
        tab.classList.add('text-gray-300');
    });
    const activeTab = document.getElementById('tab-' + tabName);
    activeTab.classList.add('active', 'bg-slate-700', 'text-white');
    activeTab.classList.remove('text-gray-300');

    updateAdminPage();
}

// Gestion des rôles
function selectRole(role) {
    selectedRole = role;
    document.querySelectorAll('.role-btn').forEach(btn => btn.classList.remove('border-amber-500', 'bg-slate-700'));
    document.getElementById('role-' + role).classList.add('border-amber-500', 'bg-slate-700');
}

// Gestion de l'image (URL ou Fichier)
function toggleImageInput(type) {
    const urlInput = document.getElementById('movie-image');
    const fileInput = document.getElementById('movie-image-file');
    const btnUrl = document.getElementById('btn-img-url');
    const btnFile = document.getElementById('btn-img-file');

    if (type === 'url') {
        urlInput.classList.remove('hidden');
        fileInput.classList.add('hidden');
        btnUrl.classList.replace('bg-slate-800', 'bg-slate-600');
        btnUrl.classList.replace('text-gray-400', 'text-white');
        btnFile.classList.replace('bg-slate-600', 'bg-slate-800');
        btnFile.classList.replace('text-white', 'text-gray-400');
    } else {
        urlInput.classList.add('hidden');
        fileInput.classList.remove('hidden');
        btnFile.classList.replace('bg-slate-800', 'bg-slate-600');
        btnFile.classList.replace('text-gray-400', 'text-white');
        btnUrl.classList.replace('bg-slate-600', 'bg-slate-800');
        btnUrl.classList.replace('text-white', 'text-gray-400');
    }
}

async function uploadImage(file) {
    const formData = new FormData();
    formData.append('file', file);

    try {
        const response = await fetch(API_BASE_URL + '/upload', {
            method: 'POST',
            body: formData
        });
        if (response.ok) {
            const data = await response.json();
            return data.url;
        }
    } catch (error) {
        console.error('Erreur upload:', error);
    }
    return null;
}

// --- COMMUNICATION AVEC LE BACKEND ---
async function apiRequest(endpoint, method = 'GET', body = null) {
    try {
        const options = {
            method,
            headers: { 'Content-Type': 'application/json' }
        };
        if (body) {
            options.body = JSON.stringify(body);
        }
        const response = await fetch(API_BASE_URL + endpoint, options);
        if (!response.ok) {
            throw new Error(`Erreur HTTP: ${response.status}`);
        }
        return response.status === 204 ? null : response.json();
    } catch (error) {
        console.error(`Erreur API pour ${method} ${endpoint}:`, error);
        showToast('Une erreur de communication est survenue.', 'error');
        return null;
    }
}

async function fetchAllData() {
    try {
        // Données publiques (accessibles à tous)
        movies = await apiRequest('/movies') || [];
        comments = await apiRequest('/comments') || [];

        // Données protégées (Admin ou Utilisateur connecté)
        if (currentUser) {
            // On essaie de récupérer les réservations (peut échouer si non-admin selon le backend, mais on tente)
            const resData = await apiRequest('/reservations');
            reservations = resData || [];

            if (currentUser.userRole === 'admin') {
                // Données strictement Admin
                const [usersData, messagesData] = await Promise.all([
                    apiRequest('/users'),
                    apiRequest('/contact')
                ]);
                users = usersData || [];
                messages = messagesData || [];
            }
        }
    } catch (error) {
        console.error("Erreur lors du chargement des données:", error);
        showToast("Erreur de chargement des données.", "error");
    }
    updateAllPages();
}

// Gestion des rôles
function selectRole(role) {
    selectedRole = role;
    document.querySelectorAll('.role-btn').forEach(btn => btn.classList.remove('border-amber-500', 'bg-slate-700'));
    document.getElementById('role-' + role).classList.add('border-amber-500', 'bg-slate-700');
}

// Gestion de l'image (URL ou Fichier)
function toggleImageInput(type) {
    const urlInput = document.getElementById('movie-image');
    const fileInput = document.getElementById('movie-image-file');
    const btnUrl = document.getElementById('btn-img-url');
    const btnFile = document.getElementById('btn-img-file');

    if (type === 'url') {
        urlInput.classList.remove('hidden');
        fileInput.classList.add('hidden');
        btnUrl.classList.replace('bg-slate-800', 'bg-slate-600');
        btnUrl.classList.replace('text-gray-400', 'text-white');
        btnFile.classList.replace('bg-slate-600', 'bg-slate-800');
        btnFile.classList.replace('text-white', 'text-gray-400');
    } else {
        urlInput.classList.add('hidden');
        fileInput.classList.remove('hidden');
        btnFile.classList.replace('bg-slate-800', 'bg-slate-600');
        btnFile.classList.replace('text-gray-400', 'text-white');
        btnUrl.classList.replace('bg-slate-600', 'bg-slate-800');
        btnUrl.classList.replace('text-white', 'text-gray-400');
    }
}

async function uploadImage(file) {
    const formData = new FormData();
    formData.append('file', file);

    try {
        const response = await fetch(API_BASE_URL + '/upload', {
            method: 'POST',
            body: formData
        });
        if (response.ok) {
            const data = await response.json();
            return data.url;
        }
    } catch (error) {
        console.error('Erreur upload:', error);
    }
    return null;
}

// --- COMMUNICATION AVEC LE BACKEND ---
async function apiRequest(endpoint, method = 'GET', body = null) {
    try {
        const options = {
            method,
            headers: { 'Content-Type': 'application/json' }
        };
        if (body) {
            options.body = JSON.stringify(body);
        }
        const url = API_BASE_URL + endpoint + (endpoint.includes('?') ? '&' : '?') + `t=${new Date().getTime()}`;
        const response = await fetch(url, options);
        if (!response.ok) {
            throw new Error(`Erreur HTTP: ${response.status}`);
        }
        return response.status === 204 ? null : response.json();
    } catch (error) {
        console.error(`Erreur API pour ${method} ${endpoint}:`, error);
        showToast('Une erreur de communication est survenue.', 'error');
        return null;
    }
}

async function fetchAllData() {
    try {
        // Données publiques (accessibles à tous)
        movies = await apiRequest('/movies') || [];
        comments = await apiRequest('/comments') || [];

        // Données protégées (Admin ou Utilisateur connecté)
        if (currentUser) {
            // On essaie de récupérer les réservations (peut échouer si non-admin selon le backend, mais on tente)
            const resData = await apiRequest('/reservations');
            reservations = resData || [];

            if (currentUser.userRole === 'admin') {
                // Données strictement Admin
                const [usersData, messagesData] = await Promise.all([
                    apiRequest('/users'),
                    apiRequest('/contact')
                ]);
                users = usersData || [];
                messages = messagesData || [];
            }
        }
    } catch (error) {
        console.error("Erreur lors du chargement des données:", error);
        showToast("Erreur de chargement des données.", "error");
    }
    updateAllPages();
}

// Authentification
function showRegisterForm() {
    document.getElementById('register-form').classList.toggle('hidden');
}

async function login(event) {
    event.preventDefault();
    const btn = event.target.querySelector('button');
    btn.classList.add('loading');

    const username = document.getElementById('login-username').value;
    const password = document.getElementById('login-password').value;

    const response = await fetch(`${API_BASE_URL}/users/login`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ username, password })
    });

    if (response.ok) {
        const user = await response.json();
        // Vérification du rôle si sélectionné (optionnel, sinon on prend le rôle de l'user)
        currentUser = user;
        localStorage.setItem('currentUser', JSON.stringify(currentUser)); // Persistance
        updateUserInterface();
        await fetchAllData();
        showPage('home');
        showToast(`Bienvenue ${user.firstName} !`);
    } else {
        showToast('Nom d\'utilisateur ou mot de passe incorrect.', 'error');
    }
    btn.classList.remove('loading');
}

async function register(event) {
    event.preventDefault();
    const btn = event.target.querySelector('button');
    btn.classList.add('loading');

    // Seul un admin connecté peut créer un admin. Sinon, c'est 'user' par défaut.
    let roleToCreate = 'user';
    if (currentUser && currentUser.userRole === 'admin' && selectedRole === 'admin') {
        roleToCreate = 'admin';
    }

    const userData = {
        username: document.getElementById('reg-username').value,
        email: document.getElementById('reg-email').value,
        password: document.getElementById('reg-password').value,
        firstName: document.getElementById('reg-firstname').value,
        lastName: document.getElementById('reg-lastname').value,
        phone: document.getElementById('reg-phone').value,
        userRole: roleToCreate,
        createdAt: new Date().toISOString()
    };

    const existingUser = users.find(u => u.username === userData.username || u.email === userData.email);
    if (existingUser) {
        showToast('Nom d\'utilisateur ou email déjà utilisé.', 'error');
        btn.classList.remove('loading');
        return;
    }

    const newUser = await apiRequest('/users', 'POST', userData);
    if (newUser) {
        await fetchAllData();
        showToast('Compte créé avec succès !');
        document.getElementById('registration-form').reset();
        document.getElementById('register-form').classList.add('hidden');
    }
    btn.classList.remove('loading');
}

function logout() {
    currentUser = null;
    localStorage.removeItem('currentUser'); // Nettoyage
    updateUserInterface();
    showPage('login');
    showToast('Déconnexion réussie.');
}

function updateUserInterface() {
    const userMenu = document.getElementById('user-menu');
    const guestMenu = document.getElementById('guest-menu');
    const navReservations = document.getElementById('nav-reservations');
    const navAdmin = document.getElementById('nav-admin');

    if (currentUser) {
        userMenu.classList.remove('hidden');
        guestMenu.classList.add('hidden');
        document.getElementById('user-welcome').textContent = `${currentUser.firstName} ${currentUser.lastName}`;
        navReservations.classList.remove('hidden');
        if (currentUser.userRole === 'admin') {
            navAdmin.classList.remove('hidden');
        } else {
            navAdmin.classList.add('hidden');
        }
    } else {
        userMenu.classList.add('hidden');
        guestMenu.classList.remove('hidden');
        navReservations.classList.add('hidden');
        navAdmin.classList.add('hidden');
    }
}

// --- GESTION DES FILMS (ADMIN) ---
async function addMovie(event) {
    event.preventDefault();
    const btn = event.target.querySelector('button');
    btn.classList.add('loading');

    let imageUrl = document.getElementById('movie-image').value;
    const imageFile = document.getElementById('movie-image-file').files[0];

    if (imageFile) {
        const uploadedUrl = await uploadImage(imageFile);
        if (uploadedUrl) {
            imageUrl = uploadedUrl;
        } else {
            showToast('Erreur lors du téléchargement de l\'image.', 'error');
            btn.classList.remove('loading');
            return;
        }
    }

    const movieData = {
        title: document.getElementById('movie-title').value,
        genre: document.getElementById('movie-genre').value,
        duration: document.getElementById('movie-duration').value,
        price: parseFloat(document.getElementById('movie-price').value),
        showtime: document.getElementById('movie-showtime').value,
        availableSeats: parseInt(document.getElementById('movie-seats').value),
        imageUrl: imageUrl,
        videoUrl: document.getElementById('movie-video').value,
        createdAt: new Date().toISOString(),
        userId: currentUser.id,
        userRole: currentUser.userRole
    };

    const result = await apiRequest('/movies', 'POST', movieData);
    if (result) {
        await fetchAllData();
        showToast('Film ajouté avec succès !');
        document.getElementById('add-movie-form').reset();
        document.getElementById('add-movie-form-container').classList.add('hidden');
    }
    btn.classList.remove('loading');
}

async function deleteMovie(movieId) {
    if (!confirm('Êtes-vous sûr de vouloir supprimer ce film ?')) return;
    const result = await apiRequest(`/movies/${movieId}`, 'DELETE');
    showToast('Film supprimé avec succès !');
    await fetchAllData();
}

function openEditMovieModal(movieId) {
    currentEditMovie = movies.find(m => m.id === movieId);
    if (!currentEditMovie) return;
    document.getElementById('edit-movie-title').value = currentEditMovie.title;
    document.getElementById('edit-movie-genre').value = currentEditMovie.genre;
    document.getElementById('edit-movie-duration').value = currentEditMovie.duration;
    document.getElementById('edit-movie-price').value = currentEditMovie.price;
    document.getElementById('edit-movie-showtime').value = currentEditMovie.showtime;
    document.getElementById('edit-movie-seats').value = currentEditMovie.availableSeats;
    document.getElementById('edit-movie-image').value = currentEditMovie.imageUrl || '';
    document.getElementById('edit-movie-video').value = currentEditMovie.videoUrl || '';
    document.getElementById('edit-movie-modal').classList.remove('hidden');
}

function closeEditMovieModal() {
    document.getElementById('edit-movie-modal').classList.add('hidden');
    currentEditMovie = null;
}

async function updateMovie(event) {
    event.preventDefault();
    if (!currentEditMovie) return;
    const btn = event.target.querySelector('button');
    btn.classList.add('loading');

    const updatedData = {
        ...currentEditMovie,
        title: document.getElementById('edit-movie-title').value,
        genre: document.getElementById('edit-movie-genre').value,
        duration: document.getElementById('edit-movie-duration').value,
        price: parseFloat(document.getElementById('edit-movie-price').value),
        showtime: document.getElementById('edit-movie-showtime').value,
        availableSeats: parseInt(document.getElementById('edit-movie-seats').value),
        imageUrl: document.getElementById('edit-movie-image').value,
        videoUrl: document.getElementById('edit-movie-video').value
    };

    const result = await apiRequest(`/movies/${currentEditMovie.id}`, 'PUT', updatedData);
    if (result) {
        await fetchAllData();
        showToast('Film modifié avec succès !');
        closeEditMovieModal();
    }
    btn.classList.remove('loading');
}

// --- GESTION DES RÉSERVATIONS ET PAIEMENT ---
function openBookingModal(movieId) {
    if (!currentUser) {
        showToast('Veuillez vous connecter pour réserver.', 'error');
        showPage('login');
        return;
    }
    currentBookingMovie = movies.find(m => m.id === movieId);
    if (!currentBookingMovie || currentBookingMovie.availableSeats <= 0) {
        showToast('Aucune place disponible.', 'error');
        return;
    }
    document.getElementById('booking-movie-info').innerHTML = `
        <div class="bg-slate-700 p-4 rounded-xl border border-slate-600">
            <h4 class="font-heading font-bold text-white text-lg">${currentBookingMovie.title}</h4>
            <p class="text-sm text-gray-300 mt-1">${currentBookingMovie.genre} • Séance: ${formatDateTime(currentBookingMovie.showtime)}</p>
            <p class="text-sm text-amber-400 font-medium mt-1">Places restantes: ${currentBookingMovie.availableSeats}</p>
        </div>`;
    updateBookingPrice();
    document.getElementById('booking-modal').classList.remove('hidden');
}

function closeBookingModal() {
    document.getElementById('booking-modal').classList.add('hidden');
    currentBookingMovie = null;
}

function updateBookingPrice() {
    if (!currentBookingMovie) return;
    const seatsCount = parseInt(document.getElementById('seats-count').value) || 1;
    const maxSeats = Math.min(10, currentBookingMovie.availableSeats);
    document.getElementById('seats-count').max = maxSeats;
    if (seatsCount > maxSeats) document.getElementById('seats-count').value = maxSeats;
    const total = (seatsCount * currentBookingMovie.price).toFixed(2);
    document.getElementById('total-price').textContent = `Total: ${total}€`;
}

function confirmBooking(event) {
    event.preventDefault();
    if (!currentBookingMovie || !currentUser) return;

    const seatsCount = parseInt(document.getElementById('seats-count').value);
    if (seatsCount > currentBookingMovie.availableSeats) {
        showToast('Pas assez de places disponibles.', 'error');
        return;
    }

    // Préparer la réservation mais ne pas l'envoyer tout de suite
    pendingBooking = {
        movieId: currentBookingMovie.id,
        title: currentBookingMovie.title,
        genre: currentBookingMovie.genre,
        showtime: currentBookingMovie.showtime,
        price: currentBookingMovie.price,
        customerName: `${currentUser.firstName} ${currentUser.lastName}`,
        customerEmail: currentUser.email,
        seatsBooked: seatsCount,
        createdAt: new Date().toISOString(),
        userId: currentUser.id,
        userRole: currentUser.userRole
    };

    // Afficher la page de paiement
    closeBookingModal();
    showPage('payment');
    document.getElementById('payment-total').textContent = (seatsCount * currentBookingMovie.price).toFixed(2) + '€';
    document.getElementById('card-holder-name').textContent = `${currentUser.firstName} ${currentUser.lastName}`;
}

async function processPayment(event) {
    event.preventDefault();
    if (!pendingBooking) return;

    const btn = event.target.querySelector('button[type="submit"]');
    const originalText = btn.textContent;
    btn.disabled = true;
    btn.textContent = 'Traitement...';

    // Simuler un délai de paiement
    await new Promise(resolve => setTimeout(resolve, 2000));

    // Créer la réservation
    const reservationResult = await apiRequest('/reservations', 'POST', pendingBooking);

    if (reservationResult) {
        const updatedMovie = {
            ...currentBookingMovie,
            availableSeats: currentBookingMovie.availableSeats - pendingBooking.seatsBooked
        };
        await apiRequest(`/movies/${currentBookingMovie.id}`, 'PUT', updatedMovie);
        await fetchAllData();
        showToast('Paiement accepté ! Réservation confirmée.');
        showPage('reservations');
        pendingBooking = null;
        document.getElementById('payment-form').reset();
    } else {
        showToast('Erreur lors de la réservation.', 'error');
    }

    btn.disabled = false;
    btn.textContent = originalText;
}

async function cancelReservation(reservationId) {
    if (!confirm('Êtes-vous sûr de vouloir annuler cette réservation ?')) return;

    const reservation = reservations.find(r => r.id === reservationId);
    if (!reservation) return;

    const movie = movies.find(m => m.id === reservation.movieId);
    if (movie) {
        const updatedMovie = { ...movie, availableSeats: movie.availableSeats + reservation.seatsBooked };
        await apiRequest(`/movies/${movie.id}`, 'PUT', updatedMovie);
    }

    await apiRequest(`/reservations/${reservationId}`, 'DELETE');
    showToast('Réservation annulée.');
    await fetchAllData();
}

// --- GESTION DES COMMENTAIRES ---
function openCommentModal(movieId) {
    if (!currentUser) {
        showToast('Veuillez vous connecter pour commenter.', 'error');
        showPage('login');
        return;
    }
    currentCommentMovie = movies.find(m => m.id === movieId);
    if (!currentCommentMovie) return;
    document.getElementById('comment-movie-info').innerHTML = `<h4 class="font-semibold">${currentCommentMovie.title}</h4>`;
    document.getElementById('comment-modal').classList.remove('hidden');
}

function closeCommentModal() {
    document.getElementById('comment-modal').classList.add('hidden');
    currentCommentMovie = null;
}

async function submitComment(event) {
    event.preventDefault();
    if (!currentCommentMovie || !currentUser) return;
    const btn = event.target.querySelector('button');
    btn.classList.add('loading');

    const commentData = {
        movieId: currentCommentMovie.id,
        comment: document.getElementById('comment-text').value,
        rating: parseInt(document.getElementById('comment-rating').value),
        authorName: `${currentUser.firstName} ${currentUser.lastName}`,
        createdAt: new Date().toISOString(),
        userId: currentUser.id,
        userRole: currentUser.userRole
    };

    const result = await apiRequest('/comments', 'POST', commentData);
    if (result) {
        await fetchAllData();
        showToast('Commentaire publié !');
        document.getElementById('comment-form').reset();
        closeCommentModal();
    }
    btn.classList.remove('loading');
}

async function deleteComment(commentId) {
    if (!confirm('Supprimer ce commentaire ?')) return;
    await apiRequest(`/comments/${commentId}`, 'DELETE');
    showToast('Commentaire supprimé.');
    await fetchAllData();
}

// --- GESTION DU CONTACT ---
async function submitContactForm(event) {
    event.preventDefault();
    const btn = event.target.querySelector('button');
    btn.classList.add('loading');

    const messageData = {
        name: document.getElementById('contact-name').value,
        email: document.getElementById('contact-email').value,
        subject: document.getElementById('contact-subject').value,
        message: document.getElementById('contact-message').value,
        createdAt: new Date().toISOString()
    };

    const result = await apiRequest('/contact', 'POST', messageData);
    if (result) {
        showToast('Message envoyé avec succès ! Nous vous répondrons bientôt.');
        document.getElementById('contact-form').reset();
    }
    btn.classList.remove('loading');
}

async function deleteMessage(messageId) {
    if (!confirm('Supprimer ce message ?')) return;
    await apiRequest(`/contact/${messageId}`, 'DELETE');
    showToast('Message supprimé.');
    await fetchAllData();
}

// --- GESTION DES UTILISATEURS (ADMIN) ---
let currentEditUser = null;

function openEditUserModal(userId) {
    currentEditUser = users.find(u => u.id === userId);
    if (!currentEditUser) return;
    document.getElementById('edit-user-id').value = currentEditUser.id;
    document.getElementById('edit-user-firstname').value = currentEditUser.firstName;
    document.getElementById('edit-user-lastname').value = currentEditUser.lastName;
    document.getElementById('edit-user-username').value = currentEditUser.username;
    document.getElementById('edit-user-email').value = currentEditUser.email;
    document.getElementById('edit-user-role').value = currentEditUser.userRole;
    document.getElementById('edit-user-modal').classList.remove('hidden');
}

function closeEditUserModal() {
    document.getElementById('edit-user-modal').classList.add('hidden');
    currentEditUser = null;
}

document.getElementById('edit-user-form').addEventListener('submit', async function (e) {
    e.preventDefault();
    if (!currentEditUser) return;

    const updatedUser = {
        ...currentEditUser,
        firstName: document.getElementById('edit-user-firstname').value,
        lastName: document.getElementById('edit-user-lastname').value,
        username: document.getElementById('edit-user-username').value,
        email: document.getElementById('edit-user-email').value,
        userRole: document.getElementById('edit-user-role').value
    };

    const result = await apiRequest(`/users/${currentEditUser.id}`, 'PUT', updatedUser);
    if (result) {
        showToast('Utilisateur mis à jour !');
        closeEditUserModal();
        await fetchAllData();
    }
});

async function deleteUser(userId) {
    if (!confirm('Êtes-vous sûr de vouloir supprimer cet utilisateur ? Cette action est irréversible.')) return;
    if (userId === currentUser.id) {
        showToast('Vous ne pouvez pas supprimer votre propre compte.', 'error');
        return;
    }

    // Vérifier s'il a des réservations
    const userReservations = reservations.filter(r => r.userId === userId);
    if (userReservations.length > 0) {
        if (!confirm(`Cet utilisateur a ${userReservations.length} réservations. Elles seront supprimées ou désassociées. Continuer ?`)) return;
    }

    try {
        await apiRequest(`/users/${userId}`, 'DELETE');
        showToast('Utilisateur supprimé.');
        await fetchAllData();
    } catch (e) {
        console.error(e);
        showToast('Erreur lors de la suppression (FK constraint?).', 'error');
    }
}

// --- GESTION DES COMMENTAIRES (ADMIN) ---
let currentEditCommentAdmin = null;

function openEditCommentModal(commentId) {
    currentEditCommentAdmin = comments.find(c => c.id === commentId);
    if (!currentEditCommentAdmin) return;
    document.getElementById('edit-comment-id').value = currentEditCommentAdmin.id;
    document.getElementById('edit-comment-text').value = currentEditCommentAdmin.comment;
    document.getElementById('edit-comment-rating').value = currentEditCommentAdmin.rating;
    document.getElementById('edit-comment-modal').classList.remove('hidden');
}

document.getElementById('edit-comment-form').addEventListener('submit', async function (e) {
    e.preventDefault();
    if (!currentEditCommentAdmin) return;

    const updatedComment = {
        ...currentEditCommentAdmin,
        comment: document.getElementById('edit-comment-text').value,
        rating: parseInt(document.getElementById('edit-comment-rating').value)
    };

    const result = await apiRequest(`/comments/${currentEditCommentAdmin.id}`, 'PUT', updatedComment);
    if (result) {
        showToast('Commentaire mis à jour !');
        document.getElementById('edit-comment-modal').classList.add('hidden');
        await fetchAllData();
    }
});

// --- MISE À JOUR DE L'INTERFACE ---
function getMovieCardHTML(movie) {
    const movieComments = comments.filter(c => c.movieId === movie.id);
    const avgRating = movieComments.length > 0 ? (movieComments.reduce((sum, c) => sum + c.rating, 0) / movieComments.length).toFixed(1) : null;

    // Gestion de l'affiche
    let posterContent;
    if (movie.imageUrl) {
        posterContent = `<img src="${movie.imageUrl}" alt="${movie.title}" class="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500">`;
    } else {
        const gradients = {
            'Action': 'from-red-600 to-orange-700',
            'Comédie': 'from-yellow-500 to-orange-600',
            'Drame': 'from-blue-600 to-indigo-700',
            'Horreur': 'from-gray-800 to-black',
            'Romance': 'from-pink-600 to-rose-700',
            'Science-Fiction': 'from-purple-600 to-indigo-700'
        };
        const gradient = gradients[movie.genre] || 'from-slate-600 to-slate-800';
        posterContent = `
            <div class="w-full h-full bg-gradient-to-br ${gradient} flex items-center justify-center">
                <span class="text-7xl transform group-hover:scale-110 group-hover:rotate-6 transition-transform duration-500 drop-shadow-lg">🎬</span>
            </div>`;
    }

    return `
        <div class="group bg-slate-800 rounded-2xl overflow-hidden shadow-xl border border-slate-700 card-hover flex flex-col h-full" onclick="showMovieDetail(${movie.id})">
            <!-- Zone Affiche -->
            <div class="h-56 relative overflow-hidden">
                ${posterContent}
                <div class="absolute inset-0 bg-black opacity-10 group-hover:opacity-0 transition-opacity"></div>
                <div class="absolute bottom-3 right-3 bg-black/60 backdrop-blur-sm px-2 py-1 rounded text-xs text-white font-mono border border-white/10">
                    ${movie.duration}
                </div>
                <div class="absolute top-3 left-3 bg-black/60 backdrop-blur-sm px-2 py-1 rounded text-xs text-amber-400 font-bold border border-amber-500/30">
                    ${movie.genre}
                </div>
            </div>
            
            <div class="p-6 flex-1 flex flex-col">
                <div class="mb-4">
                    <h4 class="text-xl font-heading font-bold text-white leading-tight group-hover:text-amber-400 transition-colors mb-2">${movie.title}</h4>
                    <div class="flex items-center text-sm text-gray-400">
                        <span class="mr-2">📅</span> ${formatDateTime(movie.showtime)}
                    </div>
                </div>
                
                <div class="space-y-3 mb-6 flex-1">
                    <div class="flex items-center justify-between p-3 bg-slate-700/50 rounded-lg border border-slate-700">
                        <span class="text-lg font-bold text-white">${movie.price}€</span>
                        <span class="${movie.availableSeats > 0 ? 'text-green-400' : 'text-red-400'} font-medium text-sm flex items-center">
                            <span class="w-2 h-2 rounded-full ${movie.availableSeats > 0 ? 'bg-green-400' : 'bg-red-400'} mr-2"></span>
                            ${movie.availableSeats} places
                        </span>
                    </div>
                    ${avgRating ? `
                    <div class="flex items-center text-amber-400 text-sm">
                        <span class="mr-1">⭐</span> <span class="font-bold">${avgRating}</span> 
                        <span class="text-gray-500 ml-1">(${movieComments.length} avis)</span>
                    </div>` : '<div class="text-sm text-gray-600 italic">Aucun avis</div>'}
                </div>

                <div class="grid grid-cols-2 gap-3 mt-auto">
                    <button onclick="event.stopPropagation(); openBookingModal(${movie.id})" 
                            ${movie.availableSeats <= 0 ? 'disabled' : ''}
                            class="w-full ${movie.availableSeats > 0 ? 'bg-amber-500 hover:bg-amber-600 text-slate-900 shadow-lg shadow-amber-500/20' : 'bg-slate-700 text-slate-500 cursor-not-allowed'} font-bold py-2.5 px-4 rounded-xl transition-all transform active:scale-95 text-sm">
                        ${movie.availableSeats > 0 ? 'Réserver' : 'Complet'}
                    </button>
                    <button onclick="event.stopPropagation(); showMovieDetail(${movie.id})" class="w-full bg-slate-700 hover:bg-slate-600 text-white font-medium py-2.5 px-4 rounded-xl transition-colors text-sm border border-slate-600 hover:border-slate-500">
                        Détails
                    </button>
                </div>
            </div>
        </div>`;
}

function updateAllPages() {
    updateHomePage();
    updateMoviesPage();
    updateReservationsPage();
    updateAdminPage();
    updateProfilePage();
    // Mettre à jour la page de détail si elle est active
    const detailPage = document.getElementById('movie-detail-page');
    if (detailPage.classList.contains('active')) {
        const movieId = document.querySelector('#movie-detail-content h1')?.dataset.movieId;
        if (movieId) showMovieDetail(parseInt(movieId));
    }
}

function updateHomePage() {
    // Nettoyage de la page d'accueil comme demandé
    const recentContainer = document.getElementById('recent-movies');
    if (recentContainer) recentContainer.innerHTML = '';

    // On peut masquer les stats si elles existent encore dans le HTML
    const statsContainer = document.querySelector('#home-page .grid');
    if (statsContainer) statsContainer.style.display = 'none';
}

function updateMoviesPage() {
    const searchTerm = document.getElementById('search-movie').value.toLowerCase();
    const filterGenre = document.getElementById('filter-genre').value;

    const filteredMovies = movies.filter(movie => {
        const matchesSearch = movie.title.toLowerCase().includes(searchTerm);
        const matchesGenre = filterGenre === '' || movie.genre === filterGenre;
        return matchesSearch && matchesGenre;
    });

    const container = document.getElementById('all-movies-grid');
    container.innerHTML = filteredMovies.length > 0 ? filteredMovies.map(getMovieCardHTML).join('') : '<p class="text-gray-400 col-span-full text-center">Aucun film ne correspond à votre recherche.</p>';
}

async function updateReservationsPage() {
    if (!currentUser) return;

    const container = document.getElementById('user-reservations-list');
    if (!container) return; // Sécurité

    // Afficher un indicateur de chargement
    container.innerHTML = '<p class="text-amber-400 animate-pulse">Chargement des réservations...</p>';

    try {
        // Utiliser l'endpoint spécifique pour être sûr de récupérer les réservations de l'utilisateur
        const userReservations = await apiRequest(`/reservations/user/${currentUser.id}`);

        if (!userReservations || userReservations.length === 0) {
            container.innerHTML = '<p class="text-gray-400 italic">Aucune réservation trouvée.</p>';
            return;
        }

        container.innerHTML = userReservations.map(res => {
            const price = res.price || 0;
            const seats = res.seatsBooked || 0;
            const total = (seats * price).toFixed(2);
            const title = res.title || 'Film inconnu';

            return `
            <div class="bg-slate-800 rounded-xl shadow-lg p-5 flex justify-between items-start border border-slate-700 hover:border-slate-600 transition-colors">
                <div>
                    <h5 class="font-heading font-bold text-white text-lg mb-1">${title}</h5>
                    <p class="text-sm text-gray-400">Places: <span class="text-white font-medium">${seats}</span> • Total: <span class="text-amber-400 font-bold">${total}€</span></p>
                    <p class="text-xs text-gray-500 mt-2">Réservé le: ${formatDateTime(res.createdAt)}</p>
                </div>
                <button onclick="cancelReservation(${res.id})" class="bg-red-500/10 hover:bg-red-500/20 text-red-400 border border-red-500/50 px-4 py-2 rounded-lg text-sm transition-colors">❌ Annuler</button>
            </div>`;
        }).join('');
    } catch (err) {
        console.error("Erreur lors de l'affichage des réservations:", err);
        container.innerHTML = '<p class="text-red-400">Erreur lors du chargement des données. Veuillez réessayer.</p>';
    }
}

function showMovieDetail(movieId) {
    const movie = movies.find(m => m.id === movieId);
    if (!movie) return;
    const movieComments = comments.filter(c => c.movieId === movieId);
    const avgRating = movieComments.length > 0 ? (movieComments.reduce((sum, c) => sum + c.rating, 0) / movieComments.length).toFixed(1) : 'Aucune note';

    // Gestion de l'affiche pour le détail
    let posterContent;
    if (movie.imageUrl) {
        posterContent = `<img src="${movie.imageUrl}" alt="${movie.title}" class="w-full rounded-xl shadow-2xl mb-6">`;
    } else {
        posterContent = ''; // Pas d'affiche par défaut en mode détail si pas d'image, ou on pourrait mettre le dégradé
    }

    // Gestion de la vidéo
    let videoContent = '';
    if (movie.videoUrl) {
        videoContent = `
            <div class="mb-8 rounded-xl overflow-hidden shadow-2xl border border-slate-700 aspect-video">
                <iframe class="w-full h-full" src="${movie.videoUrl}" title="Bande-annonce" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
            </div>`;
    }

    document.getElementById('movie-detail-content').innerHTML = `
        <div class="bg-slate-800 rounded-2xl shadow-2xl p-8 border border-slate-700">
            ${videoContent}
            <div class="grid md:grid-cols-2 gap-10">
                <div>
                    ${posterContent}
                    <h1 class="text-4xl font-heading font-bold mb-6 text-white leading-tight" data-movie-id="${movie.id}">${movie.title}</h1>
                    <div class="space-y-3 text-gray-300">
                        <p><strong class="text-white">Genre:</strong> ${movie.genre}</p>
                        <p><strong class="text-white">Prix:</strong> <span class="text-amber-400 font-bold text-xl">${movie.price}€</span></p>
                        <p><strong class="text-white">Séance:</strong> ${formatDateTime(movie.showtime)}</p>
                        <p><strong class="text-white">Places:</strong> ${movie.availableSeats}</p>
                        <p><strong class="text-white">Note:</strong> ${avgRating} ⭐</p>
                    </div>
                    <div class="flex space-x-4 mt-8">
                        <button onclick="openBookingModal(${movie.id})" class="flex-1 bg-amber-500 hover:bg-amber-600 text-slate-900 font-bold py-3 px-6 rounded-xl shadow-lg shadow-amber-500/20 transition-all transform hover:scale-105">Réserver</button>
                        <button onclick="openCommentModal(${movie.id})" class="flex-1 bg-slate-700 hover:bg-slate-600 text-white font-medium py-3 px-6 rounded-xl border border-slate-600 transition-colors">Commenter</button>
                    </div>
                </div>
                <div>
                    <h3 class="text-2xl font-heading font-bold mb-6 text-white">Commentaires</h3>
                    <div class="space-y-4 max-h-96 overflow-y-auto pr-2 custom-scrollbar">
                        ${movieComments.length === 0 ? '<p class="text-gray-500 italic">Aucun commentaire pour le moment.</p>' : movieComments.map(c => `
                            <div class="bg-slate-900/50 p-4 rounded-xl border border-slate-700/50">
                                <div class="flex justify-between items-start mb-2">
                                    <p class="font-bold text-white">${c.authorName}</p>
                                    <span class="text-amber-400 text-sm">${'⭐'.repeat(c.rating)}</span>
                                </div>
                                <p class="text-gray-300 text-sm mb-2">${c.comment}</p>
                                <p class="text-xs text-gray-500">${formatDateTime(c.createdAt)}</p>
                            </div>`).join('')
        }
                    </div>
                </div>
            </div>
        </div>`;
    showPage('movie-detail');
}

// --- GESTION DES RÉSERVATIONS (ADMIN) ---
let currentEditReservation = null;

function openEditReservationModal(resId) {
    currentEditReservation = reservations.find(r => r.id === resId);
    if (!currentEditReservation) return;

    document.getElementById('edit-reservation-id').value = currentEditReservation.id;
    document.getElementById('edit-reservation-movie').value = currentEditReservation.title;
    document.getElementById('edit-reservation-customer').value = currentEditReservation.customerName;
    document.getElementById('edit-reservation-seats').value = currentEditReservation.seatsBooked;
    document.getElementById('edit-reservation-modal').classList.remove('hidden');
}

document.getElementById('edit-reservation-form').addEventListener('submit', async function (e) {
    e.preventDefault();
    if (!currentEditReservation) return;

    const newSeats = parseInt(document.getElementById('edit-reservation-seats').value);
    const oldSeats = currentEditReservation.seatsBooked;
    const diff = newSeats - oldSeats;

    // Mise à jour de la réservation
    const updatedRes = { ...currentEditReservation, seatsBooked: newSeats };

    // Il faudrait idéalement mettre à jour les places du film aussi
    // C'est une logique métier qui devrait être côté serveur en transaction, mais on le simule ici
    if (diff !== 0) {
        const movie = movies.find(m => m.id === currentEditReservation.movieId);
        if (movie) {
            if (movie.availableSeats < diff) {
                showToast('Pas assez de places disponibles pour cette modification.', 'error');
                return;
            }
            const updatedMovie = { ...movie, availableSeats: movie.availableSeats - diff };
            await apiRequest(`/movies/${movie.id}`, 'PUT', updatedMovie);
        }
    }

    const result = await apiRequest(`/reservations/${currentEditReservation.id}`, 'PUT', updatedRes);
    if (result) {
        showToast('Réservation modifiée.');
        document.getElementById('edit-reservation-modal').classList.add('hidden');
        await fetchAllData();
    }
});

function updateAdminPage() {
    if (!currentUser || currentUser.userRole !== 'admin') return;

    // Stats
    document.getElementById('admin-stat-movies').textContent = movies.length;
    document.getElementById('admin-stat-users').textContent = users.length;
    document.getElementById('admin-stat-reservations').textContent = reservations.length;
    document.getElementById('admin-stat-messages').textContent = messages.length;

    // Movies
    const moviesContainer = document.getElementById('admin-movies-list');
    moviesContainer.innerHTML = movies.map(movie => `
        <div class="bg-slate-700/30 border border-slate-600 rounded-xl p-4 flex justify-between items-center hover:bg-slate-700/50 transition-colors">
            <div class="flex items-center">
                ${movie.imageUrl ? `<img src="${movie.imageUrl}" class="w-10 h-10 rounded-md object-cover mr-3">` : ''}
                <div>
                    <h5 class="font-bold text-white">${movie.title}</h5>
                    <p class="text-sm text-gray-400">${movie.availableSeats} places</p>
                </div>
            </div>
            <div>
                <button onclick="openEditMovieModal(${movie.id})" class="bg-blue-500/20 text-blue-400 hover:bg-blue-500/30 px-3 py-1.5 rounded-lg text-sm transition-colors">Modifier</button>
                <button onclick="deleteMovie(${movie.id})" class="bg-red-500/20 text-red-400 hover:bg-red-500/30 px-3 py-1.5 rounded-lg text-sm ml-2 transition-colors">Supprimer</button>
            </div>
        </div>`).join('');

    // Users
    const usersContainer = document.getElementById('admin-users-list');
    usersContainer.innerHTML = users.map(user => `
        <tr class="hover:bg-slate-700/50 transition-colors">
            <td class="px-4 py-3">
                <div class="font-medium text-white">${user.firstName} ${user.lastName}</div>
                <div class="text-xs text-gray-500">@${user.username}</div>
            </td>
            <td class="px-4 py-3">${user.email}</td>
            <td class="px-4 py-3">
                <span class="px-2 py-1 rounded-full text-xs font-medium ${user.userRole === 'admin' ? 'bg-purple-500/20 text-purple-400' : 'bg-blue-500/20 text-blue-400'}">
                    ${user.userRole}
                </span>
            </td>
            <td class="px-4 py-3 text-xs text-gray-400">${formatDateTime(user.createdAt)}</td>
            <td class="px-4 py-3 text-right">
                <button onclick="openEditUserModal(${user.id})" class="text-blue-400 hover:text-blue-300 mr-3">✏️</button>
                <button onclick="deleteUser(${user.id})" class="text-red-400 hover:text-red-300">🗑️</button>
            </td>
        </tr>`).join('');

    // Reservations
    const resContainer = document.getElementById('admin-reservations-list');
    resContainer.innerHTML = reservations.map(res => `
        <div class="bg-slate-700/30 border border-slate-600 rounded-xl p-4 flex justify-between items-center hover:bg-slate-700/50 transition-colors">
            <div>
                <h5 class="font-bold text-white">${res.title}</h5>
                <p class="text-sm text-gray-300">Client: ${res.customerName}</p>
                <p class="text-xs text-gray-500">${formatDateTime(res.createdAt)}</p>
            </div>
            <div class="text-right">
                <div class="text-amber-400 font-bold mb-1">${res.seatsBooked} places</div>
                <div class="flex justify-end space-x-2">
                     <button onclick="openEditReservationModal(${res.id})" class="text-xs text-blue-400 hover:underline">Modifier</button>
                     <button onclick="cancelReservation(${res.id})" class="text-xs text-red-400 hover:underline">Annuler</button>
                </div>
            </div>
        </div>`).join('');

    // Comments
    const commentsContainer = document.getElementById('admin-comments-list');
    commentsContainer.innerHTML = comments.map(c => `
        <div class="bg-slate-700/30 border border-slate-600 rounded-xl p-4 hover:bg-slate-700/50 transition-colors">
            <div class="flex justify-between items-start mb-2">
                <span class="font-bold text-white">${c.authorName}</span>
                <span class="text-amber-400 text-sm">${'⭐'.repeat(c.rating)}</span>
            </div>
            <p class="text-gray-300 text-sm mb-3">"${c.comment}"</p>
            <div class="flex justify-between items-center text-xs text-gray-500">
                <span>Film ID: ${c.movieId}</span>
                <div class="flex space-x-2">
                    <button onclick="openEditCommentModal(${c.id})" class="text-blue-400 hover:text-blue-300">Modifier</button>
                    <button onclick="deleteComment(${c.id})" class="text-red-400 hover:text-red-300">Supprimer</button>
                </div>
            </div>
        </div>`).join('');

    // Messages
    const messagesContainer = document.getElementById('admin-messages-list');
    messagesContainer.innerHTML = messages.map(msg => `
        <div class="bg-slate-700/30 border border-slate-600 rounded-xl p-4 hover:bg-slate-700/50 transition-colors">
            <div class="flex justify-between items-start mb-2">
                <h5 class="font-bold text-white">${msg.subject}</h5>
                <span class="text-xs text-gray-500">${formatDateTime(msg.createdAt)}</span>
            </div>
            <p class="text-sm text-gray-300 mb-2">${msg.message}</p>
            <div class="flex justify-between items-center mt-2">
                <span class="text-xs text-blue-400">De: ${msg.name} (${msg.email})</span>
                <button onclick="deleteMessage(${msg.id})" class="text-red-400 hover:text-red-300 text-sm">Supprimer</button>
            </div>
        </div>`).join('');
}


function updateProfilePage() {
    if (!currentUser) return;
    document.getElementById('profile-firstname').value = currentUser.firstName || '';
    document.getElementById('profile-lastname').value = currentUser.lastName || '';
    document.getElementById('profile-username').value = currentUser.username || '';
    document.getElementById('profile-email').value = currentUser.email || '';
    document.getElementById('profile-phone').value = currentUser.phone || '';
    document.getElementById('profile-role').value = currentUser.userRole;

    const userReservations = reservations.filter(r => r.userId === currentUser.id);
    document.getElementById('user-total-reservations').textContent = userReservations.length;
    document.getElementById('user-total-tickets').textContent = userReservations.reduce((sum, r) => sum + r.seatsBooked, 0);
}

// Écouteurs d'événements
document.getElementById('login-form').addEventListener('submit', login);
document.getElementById('registration-form').addEventListener('submit', register);
document.getElementById('add-movie-form').addEventListener('submit', addMovie);
document.getElementById('booking-form').addEventListener('submit', confirmBooking);
document.getElementById('payment-form').addEventListener('submit', processPayment);
// document.getElementById('profile-form').addEventListener('submit', updateProfile); // Not implemented yet
document.getElementById('comment-form').addEventListener('submit', submitComment);
document.getElementById('edit-movie-form').addEventListener('submit', updateMovie);
document.getElementById('contact-form').addEventListener('submit', submitContactForm);
document.getElementById('seats-count').addEventListener('input', updateBookingPrice);
document.getElementById('search-movie').addEventListener('input', updateMoviesPage);
document.getElementById('filter-genre').addEventListener('change', updateMoviesPage);
document.getElementById('add-user-form').addEventListener('submit', addUserAdmin);
document.getElementById('add-comment-admin-form').addEventListener('submit', submitCommentAdmin);

async function addUserAdmin(event) {
    event.preventDefault();
    if (!currentUser || currentUser.userRole !== 'admin') return;

    const btn = event.target.querySelector('button[type="submit"]');
    btn.classList.add('loading');

    const userData = {
        firstName: document.getElementById('add-user-firstname').value,
        lastName: document.getElementById('add-user-lastname').value,
        username: document.getElementById('add-user-username').value,
        email: document.getElementById('add-user-email').value,
        password: document.getElementById('add-user-password').value,
        phone: document.getElementById('add-user-phone').value,
        userRole: document.getElementById('add-user-role').value,
        createdAt: new Date().toISOString()
    };

    // Vérification existence (optionnelle car le backend le fait souvent, mais bon UX)
    const existing = users.find(u => u.username === userData.username || u.email === userData.email);
    if (existing) {
        showToast('Cet utilisateur (email ou username) existe déjà.', 'error');
        btn.classList.remove('loading');
        return;
    }

    const result = await apiRequest('/users', 'POST', userData);
    if (result) {
        showToast('Utilisateur créé avec succès !');
        document.getElementById('add-user-modal').classList.add('hidden');
        document.getElementById('add-user-form').reset();
        await fetchAllData();
    }
    btn.classList.remove('loading');
}

function openAddCommentAdminModal() {
    const movieSelect = document.getElementById('admin-comment-movie');
    const userSelect = document.getElementById('admin-comment-user');

    movieSelect.innerHTML = movies.map(m => `<option value="${m.id}">${m.title}</option>`).join('');
    userSelect.innerHTML = users.map(u => `<option value="${u.id}">${u.firstName} ${u.lastName} (${u.username})</option>`).join('');

    document.getElementById('add-comment-admin-modal').classList.remove('hidden');
}

async function submitCommentAdmin(event) {
    event.preventDefault();
    if (!currentUser || currentUser.userRole !== 'admin') return;

    const btn = event.target.querySelector('button[type="submit"]');
    btn.classList.add('loading');

    const movieId = parseInt(document.getElementById('admin-comment-movie').value);
    const userId = parseInt(document.getElementById('admin-comment-user').value);
    const selectedUser = users.find(u => u.id === userId);

    const commentData = {
        movieId: movieId,
        userId: userId,
        authorName: selectedUser ? `${selectedUser.firstName} ${selectedUser.lastName}` : 'Inconnu',
        rating: parseInt(document.getElementById('admin-comment-rating').value),
        comment: document.getElementById('admin-comment-text').value,
        createdAt: new Date().toISOString()
    };

    const result = await apiRequest('/comments', 'POST', commentData);
    if (result) {
        showToast('Commentaire ajouté !');
        document.getElementById('add-comment-admin-modal').classList.add('hidden');
        document.getElementById('add-comment-admin-form').reset();
        await fetchAllData();
    }
    btn.classList.remove('loading');
}

// Initialisation
async function init() {
    // Restauration de la session
    const storedUser = localStorage.getItem('currentUser');
    if (storedUser) {
        try {
            currentUser = JSON.parse(storedUser);
            // On pourrait vérifier si le token est toujours valide ici
        } catch (e) {
            console.error("Erreur lecture session", e);
            localStorage.removeItem('currentUser');
        }
    }

    selectRole('user');
    updateUserInterface();

    // Si l'utilisateur est déjà connecté, on peut aller sur l'accueil ou rester sur la page courante
    // Pour l'instant on va sur 'home' par défaut
    showPage('home');

    await fetchAllData();
    console.log('Application initialisée.');
}

// Lancer l'application
document.addEventListener('DOMContentLoaded', init);
