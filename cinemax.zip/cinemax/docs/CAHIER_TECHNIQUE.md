# Cahier Technique - CineMax

## Sommaire
1. [Architecture Globale](#1-architecture-globale)
2. [Stack Technique Détaillée](#2-stack-technique-détaillée)
    - [A. Backend (cinemax1)](#a-backend-cinemax1)
    - [B. Frontend (CineMaxfrontend)](#b-frontend-cinemaxfrontend)
3. [Modèle de Données (MCD) & Schéma SQL](#3-modèle-de-données-mcd--schéma-sql)
    - [3.1 Table users](#31-table-users)
    - [3.2 Table movies](#32-table-movies)
    - [3.3 Table reservations](#33-table-reservations)
    - [3.4 Table contact_messages](#34-table-contact_messages)
4. [API REST & Communication](#4-api-rest--communication)
    - [A. Gestion des Films](#a-gestion-des-films)
    - [B. Utilisateurs & Auth](#b-utilisateurs--auth)
    - [C. Réservations](#c-réservations)
5. [Charte Graphique & Design (UI/UX)](#5-charte-graphique--design-uiux)
6. [Sécurité et Évolutions Futures](#6-sécurité-et-évolutions-futures)

## 1. Architecture Globale
L'application suit une architecture **Client‑Serveur** classique, séparant nettement la logique métier (backend) et l'interface utilisateur (frontend mobile et web).

### Schéma d'Architecture Logique
```text
[ Client Android ]        [ Client Web (Admin) ]
       |                            |
       +------------+---------------+
                    | HTTPS (JSON)
                    v
            [ Serveur Spring Boot ]
                    |
            [ Base de Données MySQL ]
```

- **CineMaxfrontend** : Application Android native (Java) consommant une API REST. Architecture *Single Activity* (MainActivity) + **Fragments**.
- **cinemax1** : Backend Spring Boot exposant les services REST et servant les pages Web statiques d'administration.

---

## 2. Stack Technique Détaillée

### A. Backend (`cinemax1`)
- **Langage** : Java 17 LTS
- **Framework** : Spring Boot 3.5.8
- **Gestionnaire de Build** : Maven
- **Base de données** : MySQL 8.0+
- **ORM** : Spring Data JPA (Hibernate)
- **Dépendances Clés** :
    - `spring-boot-starter-web` : Serveur Tomcat embarqué, API REST.
    - `spring-boot-starter-data-jpa` : Abstraction pour l'accès aux données.
    - `mysql-connector-j` : Driver JDBC.
    - `lombok` : Génération de code (Getters, Setters, Builders).
    - `spring-boot-devtools` : Rechargement à chaud (Hot Swap).

### B. Frontend (`CineMaxfrontend`)
- **Plateforme** : Android (Min SDK 35, Target SDK 36)
- **Langage** : Java
- **Build System** : Gradle 8.x (Kotlin DSL)
- **Architecture UI** : XML Layouts, Material Design 3.

#### **Bibliothèques & Packages Utilisés**
| Librairie | Package / Version | Usage |
|-----------|-------------------|-------|
| **Retrofit** | `com.squareup.retrofit2:retrofit:2.9.0` | Client HTTP type-safe. Interface `ApiService`. |
| **Gson** | `com.google.code.gson:gson:2.10.1` | Sérialisation JSON. |
| **Glide** | `com.github.bumptech.glide:glide:4.16.0` | Chargement asynchrone d'images. |
| **Android Material** | `com.google.android.material:material:1.11.0` | Composants graphiques (Cards, BottomSheet). |
| **AndroidX Core** | `androidx.core:core-ktx:1.12.0` | Extensions Kotlin et compatibilité Java 8+. |

---

## 3. Modèle de Données (MCD) & Schéma SQL

Voici la définition précise des tables et des entités.

### 3.1 Table `users`
| Colonne | Type SQL | Attribut Java | Description |
|---------|----------|---------------|-------------|
| `id` | `BIGINT AUTO_INCREMENT` | `Long id` | Clé primaire. |
| `username` | `VARCHAR(50)` | `String username` | Identifiant unique. |
| `email` | `VARCHAR(100)` | `String email` | Email unique. |
| `password` | `VARCHAR(255)` | `String password` | Mot de passe (Hashé). |
| `first_name`| `VARCHAR(50)` | `String firstName` | Prénom. |
| `last_name` | `VARCHAR(50)` | `String lastName` | Nom. |
| `role` | `VARCHAR(20)` | `String userRole` | 'USER' ou 'ADMIN'. |

### 3.2 Table `movies`
| Colonne | Type SQL | Attribut Java | Description |
|---------|----------|---------------|-------------|
| `id` | `BIGINT AUTO_INCREMENT` | `Long id` | Clé primaire. |
| `title` | `VARCHAR(100)` | `String title` | Titre du film. |
| `genre` | `VARCHAR(50)` | `String genre` | Action, Comédie, etc. |
| `duration` | `VARCHAR(20)` | `String duration` | Ex: "2h 15m". |
| `price` | `DOUBLE` | `Double price` | Prix du billet. |
| `showtime` | `DATETIME` | `String showtime` | Date de la séance. |
| `available_seats`| `INT` | `Integer availableSeats`| Places restantes. |

### 3.3 Table `reservations`
| Colonne | Type SQL | Attribut Java | Description |
|---------|----------|---------------|-------------|
| `id` | `BIGINT AUTO_INCREMENT` | `Long id` | Clé primaire. |
| `user_id` | `BIGINT` | `Long userId` | FK vers User. |
| `movie_id` | `BIGINT` | `Long movieId` | FK vers Movie. |
| `seats_booked`| `INT` | `Integer seatsBooked` | Nombre de places. |
| `created_at` | `DATETIME` | `String createdAt` | Date de réservation. |

### 3.4 Table `contact_messages`
| Colonne | Type SQL | Attribut Java | Description |
|---------|----------|---------------|-------------|
| `id` | `BIGINT AUTO_INCREMENT` | `Long id` | Clé primaire. |
| `email` | `VARCHAR(100)` | `String email` | Email de l'expéditeur. |
| `subject` | `VARCHAR(100)` | `String subject` | Sujet. |
| `message` | `TEXT` | `String message` | Contenu. |

---

## 4. API REST & Communication

Toutes les réponses sont au format **JSON**.

### Structure de base URL
`http://<IP_SERVEUR>:8080/api`

### Endpoints Détaillés

#### A. Gestion des Films
*   `GET /movies` : Liste tous les films (Public).
*   `GET /movies/{id}` : Détail d'un film (Public).
*   `POST /movies` : Créer un film (Admin). requiert `{title, genre, price...}`.
*   `PUT /movies/{id}` : Mettre à jour un film (Admin).
*   `DELETE /movies/{id}` : Supprimer un film (Admin).

#### B. Utilisateurs & Auth
*   `POST /users` : Inscription.
*   `POST /users/login` : Connexion. Renvoie l'objet `User` complet si succès, code 401 si échec.
*   `GET /users` : Liste des utilisateurs (Admin).

#### C. Réservations
*   `POST /reservations` : Créer une réservation.
    *   **Payload** : `{"userId": 1, "movieId": 5, "seatsBooked": 2}`
    *   **Logique** : Vérifie disponibilité -> Décrémente stock -> Sauvegarde.
*   `GET /reservations` : Toutes les réservations (Admin).
*   `GET /reservations/user/{userId}` : Réservations d'un client spécifique.

---

## 5. Charte Graphique & Design (UI/UX)

Système de design **"Dark Cinema"**.

### **Couleurs Officielles**
| Usage | Nom Couleur | Code Hex | Apparence |
|-------|-------------|----------|-----------|
| **Fond** | `background_dark` | `#0F1014` | Noir profond (OLED friendly). |
| **Cartes** | `surface_dark` | `#1B1C22` | Gris très sombre. |
| **Action** | `primary` | `#E50914` | Rouge vif (Boutons, App Bar). |
| **Accent** | `secondary` | `#FFD700` | Jaune Or (Étoiles, Prix). |
| **Texte** | `text_primary` | `#F5F5F5` | Blanc cassé (Lisibilité optimale). |

### **Composants UI**
*   **Listes** : `RecyclerView` avec `GridLayoutManager` (2 colonnes) pour les films.
*   **Détail** : `CoordinatorLayout` avec `CollapsingToolbarLayout` pour l'effet "Parallax" sur l'affiche du film.
*   **Menu** : Bouton **Menu Global** (Haut-Droit) persistante sur tous les écrans, ouvrant un `BottomSheetDialog` de navigation.

---

## 6. Sécurité et Évolutions Futures
1.  **Hashage Mots de Passe** : Intégrer `BCryptPasswordEncoder` dans le service `UserService`.
2.  **JWT (JSON Web Tokens)** : Remplacer l'authentification actuelle (basique) par un système de tokens `Bearer` dans les headers HTTP pour sécuriser les endpoints sans retransmettre le mot de passe.
3.  **HTTPS** : Configurer un certificat SSL (via Let's Encrypt ou auto-signé) pour chiffrer les échanges.
