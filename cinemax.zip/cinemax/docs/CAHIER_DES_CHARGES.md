# Cahier des Charges - CineMax

## Sommaire
1. [Contexte et Objectifs](#1-contexte-et-objectifs)
2. [Acteurs du Système](#2-acteurs-du-système)
   - [2.1 Utilisateur Standard (Client)](#21-utilisateur-standard-client)
   - [2.2 Administrateur](#22-administrateur)
3. [Spécifications Fonctionnelles Détaillées](#3-spécifications-fonctionnelles-détaillées)
   - [3.1 Module Authentification](#31-module-authentification)
   - [3.2 Module Films (Catalogue)](#32-module-films-catalogue)
   - [3.3 Module Réservations](#33-module-réservations)
   - [3.4 Module Social & Support](#34-module-social--support)
   - [3.5 Interface d'Administration (Web)](#35-interface-dadministration-web)
4. [Exigences Non-Fonctionnelles & Contraintes](#4-exigences-non-fonctionnelles--contraintes)

## 1. Contexte et Objectifs
Le projet **CineMax** vise à créer une solution complète de réservation et de gestion de cinéma. Il se compose de deux parties interconnectées :
1.  **Application Mobile (Android)** : Destinée aux clients finaux pour consulter les films, réserver des places et gérer leur compte.
2.  **Application Web (Spring Boot + Static HTML/JS)** : Destinée à l'administration des films, à la visualisation des réservations, mais aussi accessible aux curieux pour tester l'API depuis un navigateur "de bureau".
3.  **API Backend (Spring Boot)** : Le cœur du système, fournissant les données et les règles métier pour toutes les plateformes.

L'objectif est d'offrir une expérience utilisateur fluide, immersive (thème sombre "Cinéma") et performante.

---

## 2. Acteurs du Système

### 2.1 Utilisateur Standard (Client)
*   **Inscription/Connexion** : Créer un compte sécurisé pour accéder aux fonctionnalités de réservation.
*   **Consultation** : Parcourir le catalogue des films, voir les détails (synopsis, prix, durée, genre, horaires).
*   **Réservation** : Sélectionner un film et réserver une ou plusieurs places.
*   **Gestion** : Consulter l'historique de ses réservations et pouvoir les annuler si nécessaire.
*   **Interaction** : Laisser des notes et des commentaires sur les films vus.
*   **Contact** : Envoyer des messages au support technique ou commercial.

### 2.2 Administrateur
*   **Gestion du Catalogue** : Ajouter, modifier ou supprimer des films (titre, prix, nombre de places, affiche, etc.).
*   **Supervision** : Voir toutes les réservations en temps réel.
*   **Modération** : Lire les commentaires et les messages de contact des utilisateurs.

---

## 3. Spécifications Fonctionnelles Détaillées

### 3.1 Module Authentification
*   **Enregistrement** :
    *   Données requises : Prénom, Nom, Email, Username, Mot de passe, Téléphone.
    *   Contrôle : Unicité de l'email et du username.
*   **Login** :
    *   Authentification par Username et Mot de passe.
    *   Retourne les informations complètes de l'utilisateur (dont son Rôle et son ID) pour la gestion de session.

### 3.2 Module Films (Catalogue)
*   **Liste Globale** :
    *   Affichage sous forme de cartes (Mobile) ou de grille (Web).
    *   Indicateurs visuels : Prix, Genre, Durée.
*   **Fiche Détaillée** :
    *   Synopsis complet.
    *   Note moyenne (basée sur les commentaires).
    *   Bouton d'action "Réserver" (si des places sont disponibles).

### 3.3 Module Réservations
*   **Processus** :
    *   Vérification de la disponibilité des sièges en temps réel.
    *   Calcul automatique du prix total (Prix unitaire x Nombre de places).
    *   Mise à jour immédiate du stock de places disponibles (`availableSeats`) après confirmation.
*   **Consultation ("Mes Réservations")** :
    *   Liste filtrée par l'ID de l'utilisateur connecté.
    *   Affichage de la date de création, du titre du film et du montant total.
    *   Possibilité d'annuler une réservation (ce qui ré-incrémente le stock de places du film).

### 3.4 Module Social & Support
*   **Commentaires** : Un utilisateur connecté peut poster un avis (Note 1-5 étoiles + Texte) sur un film.
*   **Contact** : Formulaire simple (Sujet, Message) pour contacter l'équipe.

### 3.5 Interface d'Administration (Web)
*   Accessible uniquement aux utilisateurs ayant le rôle `ADMIN` (contrôle côté client et serveur).
*   Dashboard permettant l'ajout rapide de nouveaux films.
*   Tableaux de bord pour visualiser l'ensemble des réservations de la plateforme.

---

## 4. Exigences Non-Fonctionnelles & Contraintes
*   **Design** : Interface "Dark Mode" obligatoire. Utilisation des couleurs Rouge (#E50914) et Or (#FFD700).
*   **Ergonomie** : Navigation intuitive. Sur Android, utilisation d'une barre de menu (Bottom Sheet ou Menu dédié) et navigation par Fragments pour éviter les rechargements lourds d'Activités.
*   **Réactivité** : L'interface Web doit être responsive. L'application Android doit gérer les changements d'orientation et les différentes tailles d'écran.
*   **Fiabilité** : Gestion des cas d'erreur (Serveur injoignable, Login incorrect, Plus de places disponibles) avec feedbacks utilisateurs (Toasts, Messages d'erreur).
