# Plan des Dossiers - CineMax

## Sommaire
1. [Racine du Projet](#1-racine-du-projet)
2. [Structure Détaillée : Backend (cinemax1)](#2-structure-détaillée--backend-cinemax1)
3. [Structure Détaillée : Frontend (CineMaxfrontend)](#3-structure-détaillée--frontend-cinemaxfrontend)
4. [Dossier de Documentation (docs/)](#4-dossier-de-documentation-docs)

Ce document reflète la structure **réelle** et actuelle du projet, qui est un monorepo contenant à la fois le backend Java Spring Boot et le frontend Android.

## 1. Racine du Projet
```text
test/
├── cinemax1/                  # [BACKEND] Projet Spring Boot
├── CineMaxfrontend/           # [FRONTEND] Projet Android Studio
└── docs/                      # [DOCUMENTATION] Cahiers des charges, techniques, diagrammes
```

---

## 2. Structure Détaillée : Backend (`cinemax1`)

Le backend suit une architecture en couches standard pour une API REST Java.

```text
cinemax1/
├── src/main/java/cinemax/
│   ├── config/              # Configuration (CORS, Sécurité)
│   ├── controller/          # Contrôleurs REST (Points d'entrée API)
│   │   ├── CommentController.java
│   │   ├── ContactMessageController.java
│   │   ├── MovieController.java
│   │   ├── ReservationController.java
│   │   └── UserController.java
│   ├── model/               # Entités JPA (Objets BDD)
│   │   ├── Comment.java
│   │   ├── ContactMessage.java
│   │   ├── Movie.java
│   │   ├── Reservation.java
│   │   └── User.java
│   ├── repository/          # Interfaces d'accès aux données (Hibernate/JPA)
│   └── service/             # Logique métier (Business Logic)
│
├── src/main/resources/
│   ├── static/              # Fichiers Web statiques (Interface Admin/Web)
│   │   ├── css/             # Feuilles de style (si séparées)
│   │   ├── js/              # Scripts JavaScript
│   │   ├── index.html       # Page principale (Administration & Client Web)
│   │   └── reservations.html # Page de test spécifique pour les réservations
│   └── application.properties # Configuration serveur (Port, Base de données)
│
└── pom.xml                  # Gestionnaire de dépendances Maven
```

---

## 3. Structure Détaillée : Frontend (`CineMaxfrontend`)

L'application Android est structurée en une seule `MainActivity` qui orchestre plusieurs `Fragments`.

```text
CineMaxfrontend/
├── app/
│   ├── src/main/java/com/example/cinemaxfrontend/
│   │   ├── adapter/             # Adaptateurs pour les listes (RecyclerView)
│   │   │   ├── MovieAdapter.java
│   │   │   └── ReservationAdapter.java
│   │   ├── model/               # Modèles de données (POJO)
│   │   │   ├── Movie.java
│   │   │   ├── Reservation.java
│   │   │   ├── User.java
│   │   │   └── ...
│   │   ├── network/             # Couche Réseau (Retrofit)
│   │   │   ├── ApiClient.java   # Instance du client HTTP
│   │   │   └── ApiService.java  # Interface de définition des routes API
│   │   ├── ContactFragment.java # Logique écran Contact
│   │   ├── HomeFragment.java    # Logique écran Accueil
│   │   ├── LoginFragment.java   # Logique écran Connexion
│   │   ├── MovieDetailFragment.java # Logique écran Détail Film
│   │   ├── RegisterFragment.java # Logique écran Inscription
│   │   ├── ReservationFragment.java # Logique écran Mes Réservations
│   │   └── MainActivity.java    # Point d'entrée unique de l'application
│   │
│   └── src/main/res/            # Ressources UI
│       ├── layout/              # Fichiers XML de mise en page
│       │   ├── activity_main.xml        # Conteneur principal
│       │   ├── fragment_home.xml        # Vue Accueil
│       │   ├── fragment_login.xml       # Vue Login
│       │   ├── fragment_movie_detail.xml # Vue Détail (Ex-Activity)
│       │   ├── fragment_reservation.xml # Vue Liste Réservations
│       │   ├── item_movie.xml           # Élément de liste (Film)
│       │   ├── item_reservation.xml     # Élément de liste (Réservation)
│       │   └── menu_layout.xml          # Menu de navigation (Bottom Sheet)
│       └── values/
│           ├── colors.xml       # Palette de couleurs (Thème Dark)
│           └── strings.xml      # Textes de l'application
│
└── build.gradle.kts             # Configuration de build Gradle (Dépendances)
```

## 4. Dossier de Documentation (`docs/`)

Ce dossier centralise toute la connaissance du projet pour les développeurs et chefs de projet.

*   **`CAHIER_DES_CHARGES.md`** : Définit le "Quoi" (Fonctionnalités, besoins utilisateur).
*   **`CAHIER_TECHNIQUE.md`** : Définit le "Comment" (Stack, conventions, architecture).
*   **`ARCHITECTURE_LOGICIELLE.md`** : Structure logique détaillée Backend/Frontend.
*   **`PLAN_DES_DOSSIERS.md`** : Cartographie l'emplacement des fichiers (ce document).
*   **`DIAGRAMMES.drawio`** : Schémas visuels (Base de données, Navigation, Architecture).
