# Guide Technique : Base de Données - Android

L'application Android ne possède pas de base de données relationnelle locale complexe (comme Room ou SQLite) pour le stockage métier. Elle agit comme un **Client Riche** qui consomme les données distantes.

## 1. Modèles de Données (POJO)
Les classes dans `com.example.cinemaxfrontend.model` sont de simples conteneurs de données (Plain Old Java Objects) qui reflètent la structure JSON de l'API.

*   **`User`** : `{ id, username, email, userRole... }`
*   **`Movie`** : `{ id, title, price... }`
*   **`Reservation`** : `{ id, userId, movieId, seatsBooked... }`

Ces objets implémentent `Serializable` pour pouvoir être passés d'un Fragment à l'autre via les `Bundle`.

## 2. Persistance Locale Légère (`SharedPreferences`)

Pour maintenir la session utilisateur sans avoir à se reconnecter à chaque lancement, l'application utilise `SharedPreferences`.

### Fichier : `UserSession`
Ce fichier XML local (interne au téléphone) stocke les paires clé-valeur suivantes :
*   `USER_ID` (Long) : L'identifiant unique de l'utilisateur connecté.
*   `USERNAME` (String) : Le nom d'utilisateur (pour l'affichage "Bonjour...").

**Exemple d'accès :**
```java
SharedPreferences prefs = context.getSharedPreferences("UserSession", Context.MODE_PRIVATE);
Long userId = prefs.getLong("USER_ID", -1);
```

## 3. Flux de Données
1.  **Lecture** : Android demande les données à l'API (`GET`).
2.  **Mémoire** : Les données sont stockées temporairement dans des listes (`ArrayList<Movie>`) au sein des Fragments ou Adapters.
3.  **Écriture** : Android envoie les modifications à l'API (`POST`/`PUT`).

Aucune donnée métier (films, réservations) n'est stockée en dur dans le téléphone pour l'instant (pas de cache hors-ligne).
