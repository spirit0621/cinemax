# Guide Technique : Base de Données - Web Local (Backend)

Ce document décrit l'architecture de données du côté serveur (Spring Boot + MySQL).

## 1. Schéma Relationnel (MySQL)

La base de données `cinemax_db` contient les tables suivantes :

### Table `users`
Stocke les informations d'authentification et de profil.
```sql
CREATE TABLE users (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(255),
    email VARCHAR(255),
    password VARCHAR(255), -- Stocké en clair pour l'instant (à hacher)
    first_name VARCHAR(255),
    last_name VARCHAR(255),
    phone VARCHAR(255),
    user_role VARCHAR(50), -- 'USER' ou 'ADMIN'
    created_at VARCHAR(255)
);
```

### Table `movies`
Catalogue des films.
```sql
CREATE TABLE movies (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(255),
    genre VARCHAR(255),
    duration VARCHAR(255),
    price DOUBLE,
    showtime VARCHAR(255),
    available_seats INT
    -- description TEXT (Optionnel)
);
```

### Table `reservations`
Lie un utilisateur à un film.
```sql
CREATE TABLE reservations (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    user_id BIGINT,
    movie_id BIGINT,
    seats_booked INT,
    created_at VARCHAR(255),
    -- Champs dénormalisés pour faciliter l'affichage
    title VARCHAR(255),
    customer_name VARCHAR(255)
);
```

## 2. Entités JPA (Java Persistence API)

Le Backend utilise Hibernate pour Mapper ces tables en objets Java.

*   **`User.java`** : Mappe la table `users`. Annotée `@Entity`.
*   **`Movie.java`** : Mappe la table `movies`.
*   **`Reservation.java`** : Mappe `reservations`.

### Relations
Pour l'instant, le projet utilise une approche **dénormalisée** ou des relations logiques simples (stockage de `userId` de type `Long`) plutôt que des relations objets complexes (`@ManyToOne User user`).
*   **Avantage** : Simplicité du JSON et de la sérialisation.
*   **Inconvénient** : Pas de contrainte de clé étrangère forte au niveau JPA par défaut.

## 3. Accès aux Données

L'accès se fait via les Interfaces `Repository` étendant `JpaRepository`.
*   `UserRepository` : `findByUsername()`, `save()`, `findById()`.
*   `MovieRepository` : `findAll()`.
*   `ReservationRepository` : `findByUserId()`.
