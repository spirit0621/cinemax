# Guide Technique : Gestion des Rôles - Android

L'application mobile adapte son interface en fonction du rôle de l'utilisateur (`userRole`).

## 1. Récupération du Rôle
Lors du Login (`POST /api/users/login`), le Backend renvoie l'objet `User` complet contenant le champ `userRole`.

**Stockage Session** :
Il est recommandé d'ajouter le stockage du rôle dans les `SharedPreferences` lors du Login, tout comme l'`USER_ID`.

```java
// Dans LoginFragment.java (À implémenter)
editor.putString("USER_ROLE", user.getUserRole());
editor.apply();
```

## 2. Adaptation de l'Interface
Le code Java peut vérifier le rôle pour masquer ou afficher des éléments.

**Exemple : Menu Admin**
```java
String role = prefs.getString("USER_ROLE", "USER");
if ("ADMIN".equals(role)) {
    btnAdminPanel.setVisibility(View.VISIBLE);
} else {
    btnAdminPanel.setVisibility(View.GONE);
}
```

## 3. Protection des Routes
Bien que l'Android puisse masquer des boutons, la vraie sécurité doit être côté serveur. L'application Android ne doit jamais être considérée comme sécurisée par elle-même.

## 4. Fonctionnalités par Rôle
*   **USER** :
    *   Voir les films
    *   Réserver des billets
    *   Voir ses propres réservations
    *   Contacter le support
*   **ADMIN** (Futur) :
    *   Ajouter/Modifier/Supprimer des films
    *   Voir toutes les réservations de tous les clients
    *   Gérer les utilisateurs
