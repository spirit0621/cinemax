# Guide Technique : Gestion des Rôles - Web Local (Backend)

La gestion des rôles permet de sécuriser l'application en distinguant les simples clients (`USER`) des administrateurs (`ADMIN`).

## 1. Modélisation
Dans la table `users` et l'entité `User.java`, le champ `userRole` (String) définit le niveau d'accès.
*   Valeurs possibles : `"USER"`, `"ADMIN"`.

## 2. Inscription
Par défaut, l'endpoint d'inscription (`POST /api/users`) attribue le rôle `"USER"` aux nouveaux inscrits (ou le rôle envoyé est stocké tel quel, attention à la sécurité).

## 3. Sécurisation des Endpoints (Logique Actuelle)
Actuellement, la sécurité est gérée logiquement dans les contrôleurs ou via l'interface front-end. Spring Security n'étant pas totalement activé en mode strict, tous les endpoints sont techniquement ouverts.

**Amélioration recommandée :**
Utiliser Spring Security pour bloquer les routes au niveau serveur :
```java
// Exemple de configuration future
http.authorizeHttpRequests()
    .requestMatchers("/api/movies/**").hasRole("ADMIN") // Seul l'admin peut modifier les films
    .anyRequest().authenticated();
```

## 4. Interface Web
*   Une page d'administration (`admin.html` ou dashboard) devrait vérifier le rôle de l'utilisateur connecté (via JS ou Session) avant d'afficher les boutons "Ajouter un film" ou "Voir toutes les réservations".
