# Guide Technique Détaillé : Affichage Accueil - Web Local

Page vitrine affichant la grille des films.

## 🔄 Flux de Données

1.  **Requête Navigateur** : Utilisateur accède à `/`.
2.  **Serveur Statique** : Spring Boot sert le fichier `index.html`.
3.  **Appel API JS** : Le script exécute `fetch('/api/movies')`.
4.  **Backend** : `MovieController` -> `MovieRepository` -> BDD.
5.  **Affichage** : Le JS génère des `<div class="movie-card">` injectées dans la grille CSS.

---

## 🔍 Architecture Détaillée

### 1. Index et Style (`index.html` / `style.css`)
*   **Conteneur** : `<div id="movies-grid">`.
*   **CSS** : Utilise `display: grid` ou `flexbox` pour l'alignement responsive des affiches.

### 2. Contrôleur (`MovieController.java`)
*   **Endpoint** : `@GetMapping("/api/movies")`.
*   **Données** : Retourne la liste complète des films.

### 3. Logique Javascript (`script.js`)
Responsable de la manipulation du DOM.
```javascript
// Pseudo-code
function displayMovies(movies) {
   const container = document.getElementById('movies-grid');
   movies.forEach(movie => {
       // Création dynamique
       const card = document.createElement('div');
       card.className = 'movie-card';
       card.innerHTML = `<h3>${movie.title}</h3>...`;
       container.appendChild(card);
   });
}
```

### 4. Modèle (`Movie.java`)
L'entité contient les infos d'affichage : `title`, `genre`, `duration`, `showtime`.
