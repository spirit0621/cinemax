# Guide Technique Détaillé : Affichage Accueil - Android

L'écran d'accueil gère l'affichage complexe de plusieurs listes horizontales de films.

## 🔄 Flux d'Exécution

1.  **Initialisation UI** : `HomeFragment` charge le layout.
2.  **Appel API Unique** : Récupère TOUS les films (`getAllMovies`).
3.  **Affichage** : Le Fragment envoie la liste complète à l'adaptateur principal `Now Showing`. (La distinction "Coming Soon" a été supprimée pour simplifier l'UI).
4.  **Mise à jour Adapters** : Notifie le `MovieAdapter`.

---

## 🔍 Architecture Détaillée

### 1. La Vue (`fragment_home.xml`)
Architecture avec défilement et Hero Section.
*   `ScrollView` (Principal)
    *   `ConstraintLayout` (Conteneur)
        *   **Hero Section** : Bannière visuelle "Vivez le Cinéma".
        *   `RecyclerView` Horizontal (Now Showing)
*   *Note : Le bouton Menu est désormais géré globalement par l'Activity.*

### 2. Le Contrôleur UI (`HomeFragment.java`)
C'est le cerveau de l'écran.
*   **Rôle** : Orchestrer les appels réseau et la séparation des données.
*   **Implémentation** : Implémente l'interface `MovieAdapter.OnItemClickListener` pour gérer les clics sur les affiches (Navigation vers Détail).

### 3. L'Adaptateur (`MovieAdapter.java`)
*   Reçoit une liste de films.
*   Lie l'image (Poster) et le texte (Titre) au Layout `item_movie.xml`.
*   Gère le clic sur un item `holder.itemView.setOnClickListener(...)` qui renvoie l'événement au Fragment parent.

### 4. Navigation
Lors d'un clic sur un film :
1.  L'Adapter notifie le Fragment via l'interface.
2.  Le Fragment appelle le `MainActivity`.
3.  `MainActivity` remplace `HomeFragment` par `MovieDetailFragment` en passant l'objet `Movie` en argument (Serializable ou Parcelable).
