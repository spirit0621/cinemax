# Guide Technique Détaillé : Affichage Contact - Android

Écran de formulaire de contact natif dans l'application.

## 🔄 Flux d'Exécution

1.  **Saisie** : Utilisateur remplit les `EditText`.
2.  **Validation** : Le Fragment vérifie si les champs sont vides quand on clique sur "Envoyer".
3.  **Envoi** : Retrofit envoie le JSON.
4.  **Feedback** : Un Toast "Message sent" s'affiche et l'utilisateur est redirigé vers l'Accueil.

---

## 🔍 Architecture Détaillée

### 1. La Vue (`fragment_contact.xml`)
Contient les champs de saisie et le bouton d'action.

### 2. Le Contrôleur UI (`ContactFragment.java`)
*   **Validation** :
    ```java
    if (name.isEmpty() || email.isEmpty() ...) {
        Toast.makeText(..., "Please fill required fields", ...);
        return;
    }
    ```
*   **Création Objet** : Instancie `ContactMessage` avec les données saisies.

### 3. Couche Réseau (`ApiService.java`)
*   Interface : `sendContactMessage(@Body ContactMessage message)`.
*   Type de retour : `Call<ContactMessage>`.

### 4. Modèle (`ContactMessage.java` - Android)
Classe POJO miroir du Backend.
*   Champs : `name`, `email`, `subject`, `message` (et `id` optionnel).
