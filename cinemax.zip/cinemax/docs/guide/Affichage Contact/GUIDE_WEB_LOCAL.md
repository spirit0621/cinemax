# Guide Technique Détaillé : Affichage Contact - Web Local

Page permettant d'envoyer un message aux administrateurs.

## 🔄 Flux de Données

1.  **Formulaire** : Utilisateur saisit son message.
2.  **JS** : Intercepte le `submit`, empêche le rechargement page (`e.preventDefault()`).
3.  **API** : `POST /api/contact`.
4.  **Backend** : `ContactMessageController` -> `ContactMessageRepository`.
5.  **Persistance** : Sauvegarde en table `contact_messages`.

---

## 🔍 Architecture Détaillée

### 1. Vue (`contact.html` ou section dans `index.html`)
Formulaire simple.
*   Inputs : `name`, `email`, `subject`, `message`.

### 2. Contrôleur (`ContactMessageController.java`)
*   **Endpoint** : `@PostMapping("/api/contact")`.
*   **Action** : Reçoit l'objet `ContactMessage` du body JSON.
*   **Retour** : Renvoie l'objet sauvegardé avec son nouvel ID (Confirmation).

### 3. Modèle (`ContactMessage.java`)
Entité simple mappant la table SQL.

### 4. Base de données
Les messages sont stockés pour être consultés ultérieurement par un administrateur (via une éventuelle interface d'admin `/admin/messages` non détaillée ici mais fonctionnant sur le même principe de `GET`).
