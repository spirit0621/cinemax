# Guide Technique Détaillé : Affichage Login - Android

*Note : Le bouton "Menu" global est visible en haut à droite, permettant une navigation rapide même depuis cet écran.*

Ce document détaille le flux d'exécution technique lors d'une connexion depuis l'application mobile Android.

## 🔄 Flux d'Exécution

1.  **Vue XML** : L'utilisateur tape son texte dans les `EditText`.
2.  **Fragment (Controller UI)** : Le bouton déclenche `loginUser()`.
3.  **Retrofit (Network)** : Sérialise la demande en JSON et l'envoie.
4.  **Backend** : Traite la demande (voir Guide Web).
5.  **Callback Android** : Reçoit la réponse (`onResponse`).
6.  **Session** : Stockage du token/ID dans `SharedPreferences`.

---

## 🔍 Architecture Détaillée

### 1. La Vue (`fragment_login.xml`)
Définit l'interface graphique.
*   **Composants** :
    *   `EditText` (`@+id/etUsername`)
    *   `EditText` (`@+id/etPassword`)
    *   `Button` (`@+id/btnLogin`)

### 2. Le Contrôleur UI (`LoginFragment.java`)
Fait le lien entre la vue et les données.
*   **Initialisation (`onCreateView`)** : `view.findViewById(...)` récupère les références.
*   **Action (`loginUser`)** :
    ```java
    // 1. Récupération des donnnées
    String username = etUsername.getText().toString();
    // 2. Création de l'objet Modèle
    User user = new User();
    user.setUsername(username);
    // 3. Appel API via le Singleton ApiClient
    apiService.login(user).enqueue(new Callback<User>() {...});
    ```

### 3. Couche Réseau (`ApiService.java` & Retrofit)
L'interface définit le contrat avec le Backend.
*   **Définition** :
    ```java
    @POST("api/users/login")
    Call<User> login(@Body User user);
    ```
*   **Rôle** : Transforme l'objet Java `User` en JSON `{"username": "...", "password": "..."}` et l'envoie via HTTP POST.

### 4. Gestion de la Réponse (Callback)
Une fois le serveur (Backend Spring) ayant répondu :
*   **Succès (Code 200)** :
    *   Extraction du body : `response.body()` (Objet User complet avec ID).
    *   **Persistance Locale** : Sauvegarde de `USER_ID` dans `SharedPreferences` ("UserSession"). C'est crucial pour maintenir la session ouverte.
    *   **Navigation** : `((MainActivity) requireActivity()).loadFragment(new HomeFragment())`.
*   **Échec (Code 401/404)** : Affichage d'un `Toast` "Login Failed".
