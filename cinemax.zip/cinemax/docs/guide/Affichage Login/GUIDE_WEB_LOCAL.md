# Guide Technique Détaillé : Affichage Login - Web Local

Ce document détaille le flux d'exécution complet pour la fonctionnalité de connexion sur l'interface Web, du clic utilisateur jusqu'à la base de données.

## 🔄 Diagramme de Flux (Sequence)

1.  **Utilisateur** : Remplit le formulaire et clique sur "Login".
2.  **Vue (HTML/JS)** : Capture l'événement, construit le JSON, envoie une requête `POST`.
3.  **Contrôleur (Spring)** : Reçoit la requête, mappe le JSON en objet Java `User`.
4.  **Service** : Vérifie les identifiants (comparaison hash mot de passe).
5.  **Repository** : Cherche l'utilisateur en BDD par `username`.
6.  **Réponse** : Retourne l'utilisateur (sans mot de passe) ou une erreur 401.

---

## 🔍 Architecture Détaillée

### 1. La Vue (`index.html` & Javascript)
Le point d'entrée est le fichier `src/main/resources/static/index.html`.
*   **Élément DOM** : Formulaire `<form id="loginForm">`.
*   **Action JS** :
    ```javascript
    // Extrait du script.js simulé
    async function login() {
        const username = document.getElementById("username").value;
        const password = document.getElementById("password").value;
        
        // Appel Asynchrone
        const response = await fetch('http://localhost:8080/api/users/login', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ username, password })
        });
    }
    ```

### 2. Le Modèle (`User.java`)
L'objet transité est défini dans `cinemax.model.User`.
*   Sert à la fois de DTO (Data Transfer Object) pour la requête entrante et d'Entité JPA pour la BDD.

### 3. Le Contrôleur (`UserController.java`)
Fichier : `cinemax.controller.UserController`
*   **Endpoint** : `@PostMapping("/login")`
*   **Rôle** : Orchestrateur. Il ne contient pas de logique métier complexe, il délègue.
    ```java
    @PostMapping("/login")
    public User login(@RequestBody User user) {
        // Appelle la couche Service
        return userService.loginUser(user.getUsername(), user.getPassword());
    }
    ```

### 4. Le Service & Repository (`UserService.java`)
Fichier : `cinemax.service.UserService`
*   **Logique** : Appelle `userRepository.findByUsername(username)`.
*   **Vérification** : Si l'utilisateur existe et que le mot de passe correspond, il est retourné. Sinon, une exception est levée (ou null retourné).

### 5. Base de Données (MySQL)
*   **Table** : `users`
*   **Requête SQL générée** : `SELECT * FROM users WHERE username = ?`
