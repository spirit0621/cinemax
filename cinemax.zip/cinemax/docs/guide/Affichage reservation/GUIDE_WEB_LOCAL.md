# Guide Technique Détaillé : Affichage Réservation - Web Local

Ce document explique comment les réservations sont récupérées et affichées sur l'interface d'administration Web.

## 🔄 Flux de Données

1.  **Chargement Page** : Le navigateur ouvre `reservations.html`.
2.  **Javascript (Load)** : Lance une requête AJAX `GET` au chargement.
3.  **Contrôleur (Backend)** : Récupère la liste complète via le Service.
4.  **Base de Données** : `SELECT * FROM reservations`.
5.  **Rendu DOM** : Le JS reçoit le JSON et crée les lignes du tableau HTML `<tr>`.

---

## 🔍 Architecture Détaillée

### 1. La Vue (`reservations.html`)
Contrairement à une architecture JSP/Thymeleaf (Server-Side Rendering), ici la page est statique et les données sont chargées dynamiquement (Client-Side Rendering).
*   **Structure** : Table HTML vide `<tbody id="reservationsTableBody">`.
*   **Script** :
    ```javascript
    fetch('/api/reservations')
        .then(response => response.json())
        .then(data => {
            // Boucle sur chaque réservation pour créer une ligne HTML
            data.forEach(reservation => addRowToTable(reservation));
        });
    ```

### 2. Le Contrôleur (`ReservationController.java`)
Point d'entrée de l'API REST.
*   **Endpoint** : `@GetMapping("/api/reservations")`
*   **Méthode** : `getAllReservations()`
*   **Retour** : `List<Reservation>`. Spring transforme automatiquement cette liste Java en tableau JSON `[{}, {}]`.

### 3. Le Modèle (`Reservation.java`)
L'entité JPA mape la table SQL.
*   **Champs Clés** : `id`, `movieId`, `customerName`, `seatsBooked`.
*   **Note** : Ce modèle contient les Foreign Keys (`userId`, `movieId`) mais aussi des champs dénormalisés (comme `title`) pour faciliter l'affichage sans jointure complexe.

### 4. Service et Repository
*   `ReservationService.java` : Appelle simplement `reservationRepository.findAll()`.
*   `ReservationRepository.java` : Interface étendant `JpaRepository`. Génère le SQL nécessaire pour tout récupérer.
