# Guide Technique Détaillé : Affichage Réservation - Android

Flux technique pour l'affichage de l'historique "Mes Réservations" sur mobile.

## 🔄 Flux d'Exécution

1.  **Ouverture Fragment** : L'utilisateur clique sur le menu "My Reservations" depuis le **Menu Global**.
2.  **Vérification Session** : Le fragment vérifie si un `USER_ID` existe localement.
3.  **Appel API** : `GET /api/reservations/user/{id}`.
4.  **Parsing JSON** : Retrofit convertit la réponse en `List<Reservation>`.
5.  **Adapter (Vue)** : L'`Adapter` recycle les vues pour afficher la liste efficacement.

---

## 🔍 Architecture Détaillée

### 1. Le Contrôleur UI (`ReservationFragment.java`)
*   **Cycle de vie (`onCreateView`)** : Initialise le `RecyclerView`.
*   **Logique de chargement** :
    1.  Récupère l'ID utilisateur : `prefs.getLong("USER_ID", -1)`.
    2.  Si ID invalide -> Redirige vers Login.
    3.  Si ID valide -> Appelle `apiService.getUserReservations(userId)`.

### 2. Couche Réseau (`ApiService.java`)
Endpoint spécifique filtré par utilisateur.
```java
@GET("api/reservations/user/{userId}")
Call<List<Reservation>> getUserReservations(@Path("userId") Long userId);
```

### 3. Le Modèle (`Reservation.java` - Android)
Classe POJO (Plain Old Java Object) correspondant exactement à la structure JSON envoyée par le Backend.
*   Doit implémenter `Serializable` (optionnel mais recommandé pour passage entre fragments).

### 4. L'Adaptateur (`ReservationAdapter.java`)
C'est le composant qui lie les données (`List<Reservation>`) à l'interface graphique (`item_reservation.xml`).
*   **`onCreateViewHolder`** : "Gonfle" (Inflate) le XML d'une carte de réservation.
*   **`onBindViewHolder`** : Remplit les champs textes (`tvMovieTitle`, `tvSeats`) avec les données de l'objet Reservation à la position donnée.

### 5. La Vue (`fragment_reservation.xml` & `item_reservation.xml`)
*   Le Fragment contient le conteneur `RecyclerView`.
*   L'Item définit le look d'une cellule unique (CardView avec titre et détails).
*   **État Vide** : Le contrôleur gère la visibilité d'un `TextView` ("No reservations") si la liste retournée est vide.
