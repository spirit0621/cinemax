# Document d'Architecture Logicielle - CineMax

Ce document décrit la structure logique détaillée de la solution CineMax, couvrant le Backend (API) et le Frontend (Android), ainsi que les flux de données.

## 1. Vue d'Ensemble

Le système CineMax repose sur une architecture **N-Tiers** classique :

*   **Tier de Présentation (Client)** : Application Android.
*   **Tier Logique (Serveur)** : API REST Spring Boot.
*   **Tier de Données (Persistance)** : Base de données MySQL.

---

## 2. Architecture Backend (`cinemax1`)

Le Backend est construit avec **Spring Boot** et suit le pattern **MVC** (Model-View-Controller) adapté aux API REST (donc sans "View" côté serveur).

### Couches Logicielles (Layers)

1.  **Controller Layer (`*.controller`)**
    *   **Rôle** : Point d'entrée de l'API. Reçoit les requêtes HTTP, valide les inputs, et appelle le Service.
    *   **Composants** :
        *   `MovieController` : Gestion du catalogue (/api/movies).
        *   `UserController` : Auth et gestion utilisateurs (/api/users).
        *   `ReservationController` : Prise de commandes (/api/reservations).

2.  **Service Layer (`*.service`)**
    *   **Rôle** : Cœur de la logique métier. Contient les règles de gestion.
    *   **Composants** :
        *   `UserService` : Hashage de mdp, vérification unicité email.
        *   `ReservationService` : Vérification des places disponibles, décrémentation du stock, transaction atomique.

3.  **Repository Layer (`*.repository`)**
    *   **Rôle** : Abstraction de l'accès aux données (DAO).
    *   **Technologie** : Spring Data JPA.
    *   **Interfaces** : `UserRepository`, `MovieRepository`, etc. (Extension de `JpaRepository`).

4.  **Model Layer (`*.model`)**
    *   **Rôle** : Représentation des données persistantes (Entités).
    *   **Entités** : `User`, `Movie`, `Reservation`, `ContactMessage`.

---

## 3. Architecture Frontend (`CineMaxfrontend`)

L'application Android suit une architecture basée sur les **Fragments** et le pattern **MV-Adapter**.

### Structure des Packages

1.  **UI Controller (`com.example.cinemaxfrontend`)**
    *   **MainActivity** : Conteneur global, gère la navigation et le Menu Global.
    *   **Fragments** (`HomeFragment`, `LoginFragment`, `ReservationFragment`) : Affichent les vues et gèrent les interactions utilisateur.

2.  **Network Layer (`.network`)**
    *   **ApiClient** : Singleton configurant Retrofit (Base URL, Convertisseurs JSON).
    *   **ApiService** : Interface décrivant les endpoints de l'API (GET, POST).

3.  **Data Adapter (`.adapter`)**
    *   **Rôle** : Pont entre les données (Liste d'objets) et l'interface utilisateur (le **RecyclerView**, composant de liste défilante).
    *   **Composants** : `MovieAdapter`, `ReservationAdapter`. Gèrent le recyclage des vues pour la performance.

4.  **Model Layer (`.model`)**
    *   **Rôle** : POJOs (Plain Old Java Objects) simples reflétant la structure JSON reçue du serveur.

---

## 4. Flux de Données (Data Flow)

### Exemple : Flux de Réservation

1.  **User Action** : L'utilisateur clique sur "Réserver" dans l'app Android.
2.  **Frontend Logic** :
    *   `MovieDetailActivity` crée un objet JSON `Reservation` avec `userId` et `movieId`.
    *   Appel via `Retrofit` -> POST `/api/reservations`.
3.  **Backend Controller** :
    *   `ReservationController` reçoit le JSON.
    *   Délègue à `ReservationService`.
4.  **Backend Service** :
    *   Vérifie si `movie.availableSeats > 0`.
    *   Si OUI : `movie.availableSeats - 1`.
    *   Sauvegarde la Réservation (`reservationRepository.save()`).
    *   Met à jour le Film (`movieRepository.save()`).
5.  **Response** :
    *   Le serveur renvoie 200 OK avec la confirmation.
    *   L'app Android affiche un Toast "Réservation réussie" et redirige vers l'accueil.

---

## 6. Référence Technique Détaillée : Backend

Cette section liste exhaustivement les composants techniques du serveur.

### 6.1 Entités (Entities)
Classes Java mappées en base de données (`cinemax.model`).

| Classe | Description | Table SQL |
|--------|-------------|-----------|
| `User` | Utilisateur (Client ou Admin). | `users` |
| `Movie` | Film (Titre, Genre, Prix...). | `movies` |
| `Reservation` | Réservation (Lien User-Movie). | `reservations` |
| `Comment` | Avis utilisateur sur un film. | `comments` |
| `ContactMessage` | Message formulaire de contact. | `contact_messages` |

### 6.2 Services (Business Logic)
Classes contenant la logique métier (`cinemax.service`).

*   `UserService` : Gestion des utilisateurs & Authentification.
*   `MovieService` : CRUD Films.
*   `ReservationService` : Logique de réservation (Stock, Validation).
*   `CommentService` : Gestion des avis.
*   `ContactMessageService` : Traitement des messages de contact.

### 6.3 Contrôleurs & Request Mappings (API Endpoints)
Points d'entrée REST (`cinemax.controller`).

#### **`UserController`** (`/api/users`)
*   `GET /` : Lister tous les utilisateurs.
*   `GET /{id}` : Détails d'un utilisateur.
*   `POST /` : Créer un compte.
*   `PUT /{id}` : Modifier un compte.
*   `DELETE /{id}` : Supprimer un compte.
*   `POST /login` : Authentification (Retourne l'User si succès).

#### **`MovieController`** (`/api/movies`)
*   `GET /` : Lister tous les films.
*   `GET /{id}` : Détails d'un film.
*   `POST /` : Ajouter un film (Admin).
*   `PUT /{id}` : Modifier un film (Admin).
*   `DELETE /{id}` : Supprimer un film (Admin).

#### **`ReservationController`** (`/api/reservations`)
*   `GET /` : Lister toutes les réservations.
*   `GET /{id}` : Détail d'une réservation.
*   `GET /user/{userId}` : Réservations d'un utilisateur spécifique.
*   `POST /` : Créer une réservation.
*   `PUT /{id}` : Modifier une réservation.
*   `DELETE /{id}` : Annuler une réservation.

#### **`CommentController`** (`/api/comments`)
*   `GET /` : Tous les commentaires.
*   `GET /{id}` : Commentaire par ID.
*   `GET /movie/{movieId}` : Commentaires d'un film.
*   `POST /` : Ajouter un commentaire.
*   `PUT /{id}` : Modifier.
*   `DELETE /{id}` : Supprimer.

#### **`ContactMessageController`** (`/api/contact`)
*   `GET /` : Lire les messages reçus.
*   `POST /` : Envoyer un message.
*   `DELETE /{id}` : Supprimer un message.

#### **`FileUploadController`** (`/api/upload`)
*   `POST /` : Upload de fichier (Image film). Retourne l'URL.
